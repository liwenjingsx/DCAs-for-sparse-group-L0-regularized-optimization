
clc, clear all, close all, warning off
addpath(genpath(fileparts(mfilename('fullpath'))));
FIELDS={'GPDASC'}; % all available solvers:
for fig = 1:2
    %%%%%%%%
    % Fig
    %%%%%%%%
    if fig == 1
        %----------------------   Generate data  ---------------------------------%
        p = 1000;             % length of solution
        n = 500;              % number of samples
        Ks = 250;
        Kg = 15;
        dopts.sigma = 0.001;
        dopts.cor = 0;
        dopts.ratio = 2;
        maxnumtest = 1;      % number of realizations
        Sstopiternum = zeros(100,maxnumtest);
        dopts.seednum =0;
        for l = 1:maxnumtest
            dopts.seednum = dopts.seednum + l;        % seed number
            [X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata(n,p,Ks,Kg,dopts);
            fid = 1;
            %% GPDASC(solves  min lambda*||x||_{2,0} + 1/2 ||Ax-y||_^2)
            ff = 'GPDASC';
            if ismember(ff,FIELDS)
                printf = @(varargin) fprintf(fid,varargin{:});
                printf('\n-- %s, at %s --\n',ff,datestr(now));
                % set parameters
                opts = setopts(gidx,invXgsqrt,'gpdas');
                opts.scale = 1;
                opts.MaxIt = 1;
                opts.del = norm(y-ye);
                opts.alpha = 0;
                tic,
                [x,lam,ithist,A] = grouppdas(X,Xt,y,opts);
                pdascgl0time = toc;
                Sstopiternum(1:length(ithist.it),l) = ithist.it;
            end
        end
        %% Compute average performance
        aveSstopiternum = mean(Sstopiternum,2);
        id = find(aveSstopiternum);
        aveSstopiternum = ceil(aveSstopiternum(id));
        %% plot results
        figure(1),
        Xo = X(:,supp);
        oracle = zeros(p,1);
        oracle(supp) = (Xo'*Xo)\Xo'*y;
        len  = size(ithist.x,2);
        erroracle = [];
        for k = 1:len
            xk = ithist.x(:,k);
            erroracle = [erroracle;norm(xk - oracle)];
        end
        erroracle = erroracle/norm(oracle);
        semilogy(1:len,erroracle,'--r.','LineWidth',3),
        h = xlabel(' $s$ index for $\lambda_{s}$');
        set(h,'Interpreter','latex','fontsize',20)
        h = ylabel('error');
        set(h,'Interpreter','latex','fontsize',20)
        axis([0 40 1e-5 1e1])
    elseif fig == 2
        %%%%%%%%
        % Fig
        %%%%%%%%
        %----------------------   Generate data  ---------------------------------%
        p = 1000;             % length of solution
        n = 500;              % number of samples
        Ks = 250;
        Kg = 15;
        dopts.sigma = 0.001;
        dopts.cor = 1;
        dopts.ratio = 2;
        maxnumtest = 1;      % number of realizations
        Sstopiternum = zeros(100,maxnumtest);
        dopts.seednum = 1;
        for l = 1:maxnumtest
            dopts.seednum = dopts.seednum + l;        % seed number
            [X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata(n,p,Ks,Kg,dopts);
            fid = 1;
            %% GPDASC(solves  min lambda*||x||_{2,0} + 1/2 ||Ax-y||_^2)
            ff = 'GPDASC';
            if ismember(ff,FIELDS)
                printf('\n-- %s, at %s --\n',ff,datestr(now));
                % set parameters
                opts = setopts(gidx,invXgsqrt,'gpdas');
                opts.scale = 1;
                opts.del = norm(y-ye);
                opts.alpha = 0;
                opts.MaxIt = 1;
                tic,
                [x,lam,ithist,A] = grouppdas(X,Xt,y,opts);
                pdascgl0time = toc;
                Sstopiternum(1:length(ithist.it),l) = ithist.it;
            end
        end
        %% Compute average performance
        aveSstopiternum = mean(Sstopiternum,2);
        id = find(aveSstopiternum);
        aveSstopiternum = ceil(aveSstopiternum(id));
        %% plot results
       figure(2),
        Xo = X(:,supp);
        oracle = zeros(p,1);
        oracle(supp) = (Xo'*Xo)\Xo'*y;
        len  = size(ithist.x,2);
        erroracle = [];
        for k = 1:len
            xk = ithist.x(:,k);
            erroracle = [erroracle;norm(xk - oracle)];
        end
        erroracle = erroracle/norm(oracle);
        semilogy(1:len,erroracle,'--r.','LineWidth',3),
        h = xlabel(' $s$ index for $\lambda_{s}$');
        set(h,'Interpreter','latex','fontsize',20)
        h = ylabel(' error');
        set(h,'Interpreter','latex','fontsize',20)
        axis([0 40 1e-5 1e1])
    end
end
