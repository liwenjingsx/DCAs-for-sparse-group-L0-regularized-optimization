clc, clear all, close all
addpath(genpath(fileparts(mfilename('fullpath'))));
FIELDS={'GPDASC','GOMP','GSPGl1','GCD'}; % all available solvers
%%%%%%%%
% Fig 
%%%%%%%%
%----------------------   Generate data  ---------------------------------%
dopts.sigma = 0.01;
dopts.cor = 0;   
dopts.seednum  = 0;
dopts.twodim = 2;
[X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg,out] = gendata([],[],[],[],dopts);
id = [1:3:(64^2-1)*3+1,2:3:(64^2-1)*3+2,3:3:(64^2-1)*3+3]';
Ir = out.I(:,:,1);
Ig = out.I(:,:,2);
Ib = out.I(:,:,3);
scale = max(max(max(out.I))) - min(min(min(out.I)));
Ibar = out.Ibar;
Ibarr = Ibar(1);
Ibarg = Ibar(2);
Ibarb = Ibar(3);
figure(1)
subplot(2,3,1)
imshow(out.I,[])
h = title('Original');
set(h,'Interpreter','latex','fontsize',13)
Scputime = [];
Serror = [];
Spsnr = [];
%% GPDASC (solves  min lambda*||x||_{2,0} + 1/2 ||Ax-y||_^2)
fid = 1;
 printf = @(varargin) fprintf(fid,varargin{:});
 ff = 'GPDASC';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     % set parameters
     opts = setopts(gidx,invXgsqrt,'gpdas');
     opts.scale = 1;
     opts.del = norm(y-ye);
     opts.alpha = 0;
     opts.Lmin = 1e-10;
     tic, 
     [c,lam,ithist,A] = grouppdas(X,Xt,y,opts);
     timegpdasc = toc
     c = c(id);
     cr = c(1:64^2);
     cg = c(64^2+1:2*64^2);
     cb = c(2*64^2+1:3*64^2);
     xr = out.W(reshape(cr,[64 64])) + Ibarr;
     xg = out.W(reshape(cg,[64 64])) + Ibarg;
     xb = out.W(reshape(cb,[64 64])) + Ibarb;
     x2d = zeros(64,64,3);
     x2d(:,:,1) = xr;
     x2d(:,:,2) = xg;
     x2d(:,:,3) = xb;
     psnrgpdasc = psnr(out.I,x2d,scale);
     Scputime = [Scputime;timegpdasc];
     Spsnr = [Spsnr;psnrgpdasc];
     error = norm(x2d(:)-out.I(:));
     Serror = [Serror;error];
     subplot(2,3,2)
     imshow(x2d,[])
     h = title('GPDASC');
     set(h,'Interpreter','latex','fontsize',13)
 end
%% OMP
ff = 'GOMP';
 if ismember(ff,FIELDS)
    printf('\n-- %s, at %s --\n',ff,datestr(now));
    tic,
    opts = setopts(gidx,invXgsqrt,'gomp');
    opts.del = norm(ye-y);
    opts.alpha = 0;
    c = groupomp(X,Xt,y,opts);
    timegomp = toc
    c = c(id);
    cr = c(1:64^2);
     cg = c(64^2+1:2*64^2);
     cb = c(2*64^2+1:3*64^2);
     xr = out.W(reshape(cr,[64 64]))+Ibarr;
     xg = out.W(reshape(cg,[64 64]))+Ibarg;
     xb = out.W(reshape(cb,[64 64]))+Ibarb;
     x2d = zeros(64,64,3);
     x2d(:,:,1) = xr;
     x2d(:,:,2) = xg;
     x2d(:,:,3) = xb;
     psnrgomp = psnr(out.I,x2d,scale);
     Scputime = [Scputime;timegomp];
     Spsnr = [Spsnr;psnrgomp];
     error = norm(x2d(:)-out.I(:));
     Serror = [Serror;error];
     subplot(2,3,3)
     imshow(x2d,[])
     h = title('GOMP');
     set(h,'Interpreter','latex','fontsize',13)
end
 %% GSPGL1 (solves   minimize ||x||_{2,1} S.T. ||Ax-y||<=del)
 ff = 'GSPGl1';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     del = norm(y-ye);
     tic,
     opts = spgSetParms('verbosity',0);
     c    = spg_group(X,y,gidx,del,opts);
     timegspgl1 = toc
     c = c(id);
     cr = c(1:64^2);
     cg = c(64^2+1:2*64^2);
     cb = c(2*64^2+1:3*64^2);
     xr = out.W(reshape(cr,[64 64]))+Ibarr;
     xg = out.W(reshape(cg,[64 64]))+Ibarg;
     xb = out.W(reshape(cb,[64 64]))+Ibarb;
     x2d = zeros(64,64,3);
     x2d(:,:,1) = xr;
     x2d(:,:,2) = xg;
     x2d(:,:,3) = xb;
     psnrgspgl1 = psnr(out.I,x2d,scale);
     Scputime = [Scputime;timegspgl1];
     Spsnr = [Spsnr;psnrgspgl1]; 
     error = norm(x2d(:)-out.I(:));
     Serror = [Serror;error];
     subplot(2,3,4)
     imshow(x2d)
     h = title('SPGl1');
     set(h,'Interpreter','latex','fontsize',13)
 end
 %% GCD (solves  Group MCP)
 ff = 'GCD';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     rX = X;
     for kk = 1:max(gidx)
         ind   = find(gidx == kk);
         rX(:,ind) = X(:,ind)*(invXgsqrt{kk} + 0*eye(length(ind)));
     end
     rho  = 'mcp'; % lasso, mcp or scad
     opts = setopts(gidx,invXgsqrt,rho);
     opts.del = norm(ye-y);
     opts.mu = 0.5;
     tic,
     [c,ithist] = groupcd(rX,y,rho,opts);
     for kk = 1:max(gidx)
         ind   = find(gidx == kk);
          c(ind) = invXgsqrt{kk}*c(ind);
     end
     timegcd = toc
     c = c(id);
     cr = c(1:64^2);
     cg = c(64^2+1:2*64^2);
     cb = c(2*64^2+1:3*64^2);
     xr = out.W(reshape(cr,[64 64]))+Ibarr;
     xg = out.W(reshape(cg,[64 64]))+Ibarg;
     xb = out.W(reshape(cb,[64 64]))+Ibarb;
     x2d = zeros(64,64,3);
     x2d(:,:,1) = xr;
     x2d(:,:,2) = xg;
     x2d(:,:,3) = xb;
     psnrgcd = psnr(out.I,x2d,scale);
     Scputime = [Scputime;timegcd];
     Spsnr = [Spsnr;psnrgcd]; 
     error = norm(x2d(:)-out.I(:));
     Serror = [Serror;error];
     subplot(2,3,5)
     imshow(x2d,[])
     h = title('GCD');
     set(h,'Interpreter','latex','fontsize',13)
 end
 Scputime
 Spsnr