clc, clear all, close all
addpath(genpath(fileparts(mfilename('fullpath'))));
FIELDS={'GPDASC','GOMP','GSPGl1','GCD'}; % all available solvers
%%%%%%%%
% Fig 
%%%%%%%%
%----------------------   Generate data  ---------------------------------%
dopts.sigma = 0.03;
dopts.cor = 10;   
dopts.seednum  = 0;
dopts.twodim = 1;
[X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata([],[],[],[],dopts);
id = [1:3:(48^2-1)*3+1,2:3:(48^2-1)*3+2,3:3:(48^2-1)*3+3]';
figure(1)
subplot(2,4,1)
imshow(reshape(xe(id),48,48,3),[])
h = title('Original');
set(h,'Interpreter','latex','fontsize',13)
Scputime = [];
Spsnr = [];
MSE=[];
%% DC
maxiter1=30000;maxiter2=30000;tol=1e-7;rho=2;deta=10;lambda=0.3;lambda1=0.1;lambda2=0.1;n=6912;
%m=1152;A=orth(randn(n,m))';b=A*xe+0.02*randn(m,1);
A=X;b=y;
Lf=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*b,inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*b),inf)]);
%Ls=2*eigs(A*A',1)
Ls=2*norm(A'*A);
c=Ls/4;alphaB=Ls/4;
v=0.99*min(lambda1/Lf,deta);
%alg1_1 R1
tic
[x_new_R1,iter_R1,a_R1] = alg1_1_R1( n, A, b, lambda1, lambda2, alphaB, deta, v, c, rho, maxiter1, tol,Ls);
%[x_new,iter,a] = alg1( n, A, b, lambda, deta, v, c, rho, maxiter1, tol,Ls);
Time_R1=toc;
x_new=x_new_R1;
Scputime = [Scputime;Time_R1];
Iter_R1=iter_R1;
MSE_R1=norm(x_new-xe)^2/n;
Z_R1=sum(abs(x_new) > 0);
fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', Iter_R1, Time_R1, MSE_R1);
fprintf(' Z1 = %3d\n a = %3d\n',  Z_R1,a_R1);
x=x_new;
psnr_R1 = psnr(x,xe)
%psnr1_1 = -10*log10(norm(x-xe)^2/n)
Spsnr = [Spsnr;psnr_R1];
MSE=[MSE;MSE_R1];
subplot(2,4,2)
     imshow(reshape(x(id),48,48,3),[])
     h = title('Alg.3.1(N=1)');
     set(h,'Interpreter','latex','fontsize',13)
%alg1_1 R2
tic
[x_new_R2,iter_R2,a_R2] = alg1_1_R2( n, A, b, lambda1, lambda2, alphaB, deta, v, c, rho, maxiter1, tol,Ls);
%[x_new,iter,a] = alg1( n, A, b, lambda, deta, v, c, rho, maxiter1, tol,Ls);
Time_R2=toc;
x_new=x_new_R2;
Scputime = [Scputime;Time_R2];
Iter_R2=iter_R2;
MSE_R2=norm(x_new-xe)^2/n;
Z_R2=sum(abs(x_new) > 0);
fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', Iter_R1, Time_R1, MSE_R1);
fprintf(' Z1 = %3d\n a = %3d\n',  Z_R1,a_R1);
x=x_new;
psnr_R2 = psnr(x,xe)
%psnr1_2 = -10*log10(norm(x-xe)^2/n)
Spsnr = [Spsnr;psnr_R2];
MSE=[MSE;MSE_R2];
subplot(2,4,3)
     imshow(reshape(x(id),48,48,3),[])
     h = title('Alg.3.1(N=2)');
     set(h,'Interpreter','latex','fontsize',13)
%alg1_1 R3
tic
[x_new_R3,iter_R3,a_R3] = alg1_1_R3( n, A, b, lambda1, lambda2, alphaB, deta, v, c, rho, maxiter1, tol,Ls);
%[x_new,iter,a] = alg1( n, A, b, lambda, deta, v, c, rho, maxiter1, tol,Ls);
Time_R3=toc;
x_new=x_new_R3;
Scputime = [Scputime;Time_R3];
Iter_R3=iter_R3;
MSE_R3=norm(x_new-xe)^2/n;
Z_R3=sum(abs(x_new) > 0);
fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', Iter_R3, Time_R3, MSE_R3);
fprintf(' Z1 = %3d\n a = %3d\n',  Z_R3,a_R3);
x=x_new;
psnr_R3 = psnr(x,xe)
%psnr1_3 = -10*log10(norm(x-xe)^2/n)
Spsnr = [Spsnr;psnr_R3];
MSE=[MSE;MSE_R3];
subplot(2,4,4)
     imshow(reshape(x(id),48,48,3),[])
     h = title('Alg.3.1(N=3)');
     set(h,'Interpreter','latex','fontsize',13)
%%alg2_1
%tic
%[x_new2,iter2] = alg2_1( n, A, b, Ls, lambda1, lambda2, deta, v, maxiter2, tol);
%%[x_new2,iter2] = alg2( n, A, b, Ls, lambda, deta, v, maxiter2, tol);
%Time_ag2=toc;
%Scputime = [Scputime;Time_ag2];
%Iter_ag2=iter2;
%MSE_ag2=norm(x_new2-xe)^2/n;
%Z_ag2=sum(abs(x_new2) > 0);
%fprintf(' iter2 = %5.2d  time2 = %5.2f  MSE2 = %3.2d\n', mean(Iter_ag2), mean(Time_ag2), mean(MSE_ag2));
%fprintf(' Z2 = %3d\n',mean(Z_ag2));
%x=x_new2;
%psnr2_1 = psnr(x,xe)
%%psnr2_1 = -10*log10(norm(x-xe)^2/n)
%Spsnr = [Spsnr;psnr2_1];
%MSE=[MSE;MSE_ag2];
%subplot(2,4,3)
%     imshow(reshape(x(id),48,48,3),[])
%     h = title('Alg.3.2');
%     set(h,'Interpreter','latex','fontsize',13)

%%alg1
%tic
%%[x_new,iter,a] = alg1_1( n, A, b, lambda1, lambda2, deta, v, c, rho, maxiter1, tol,Ls);
%[x_new,iter,a] = alg1( n, A, b, lambda, deta, v, c, rho, maxiter1, tol,Ls);
%Time_ag1=toc;
%Iter_ag1=iter;
%MSE_ag1=norm(x_new-xe)^2/n;
%Z_ag1=sum(abs(x_new) > 0);
%a_ag1=a;
%fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', mean(Iter_ag1), mean(Time_ag1), mean(MSE_ag1));
%fprintf(' Z1 = %3d\n a = %3d\n',  mean(Z_ag1),mean(a_ag1));
%x=x_new;
%psnr1 = psnr(x,xe)
%subplot(2,4,2)
%     imshow(reshape(x(id),48,48,3),[])
%     h = title('DC');
%     set(h,'Interpreter','latex','fontsize',13)
%%alg2
%tic
%[x_new2,iter2] = alg2_1( n, A, b, Ls, lambda1, lambda2, deta, v, maxiter2, tol);
%[x_new2,iter2] = alg2( n, A, b, Ls, lambda, deta, v, maxiter2, tol);
%Time_ag2=toc;
%Iter_ag2=iter2;
%MSE_ag2=norm(x_new2-xe)^2/n;
%Z_ag2=sum(abs(x_new2) > 0);
%fprintf(' iter2 = %5.2d  time2 = %5.2f  MSE2 = %3.2d\n', mean(Iter_ag2), mean(Time_ag2), mean(MSE_ag2));
%fprintf(' Z2 = %3d\n',mean(Z_ag2));
%x=x_new2;
%psnr2 = psnr(x,xe)
%subplot(2,4,3)
%     imshow(reshape(x(id),48,48,3),[])
%     h = title('DC2');
%     set(h,'Interpreter','latex','fontsize',13)
%% GPDASC (solves  min lambda*||x||_{2,0} + 1/2 ||Ax-y||_^2)
fid = 1;
 printf = @(varargin) fprintf(fid,varargin{:});
 ff = 'GPDASC';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     % set parameters
     opts = setopts(gidx,invXgsqrt,'gpdas');
     opts.scale = 1;
     opts.del = norm(y-ye);
     opts.alpha = 0;
     opts.Lmin = 1e-15;
     tic, 
     [x,lam,ithist,A] = grouppdas(X,Xt,y,opts);
     timegpdasc = toc;
     Z_gpdasc=sum(abs(x) > 0)
     MSE_gpdasc=norm(x-xe)^2/n;
     psnrgpdasc = psnr(x,xe)
     %psnrgpdasc = -10*log10(norm(x-xe)^2/n)
     Scputime = [Scputime;timegpdasc];
     Spsnr = [Spsnr;psnrgpdasc];
     MSE=[MSE;MSE_gpdasc];
     subplot(2,4,6)
     imshow(reshape(x(id),48,48,3),[])
     h = title('GPDASC');
     set(h,'Interpreter','latex','fontsize',13)
 end
%% OMP
ff = 'GOMP';
 if ismember(ff,FIELDS)
    printf('\n-- %s, at %s --\n',ff,datestr(now));
    tic,
    opts = setopts(gidx,invXgsqrt,'gomp');
    opts.del = norm(ye-y);
    opts.alpha = 0;
    x = groupomp(X,Xt,y,opts);
    timegomp = toc;
    MSE_gomp=norm(x-xe)^2/n;
     psnrgomp = psnr(x,xe)
     %psnrgomp = -10*log10(norm(x-xe)^2/n)
     Scputime = [Scputime;timegomp];
     Spsnr = [Spsnr;psnrgomp];
     MSE=[MSE;MSE_gomp];
      subplot(2,4,7)
     imshow(reshape(x(id),48,48,3),[])
     h = title('GOMP');
     set(h,'Interpreter','latex','fontsize',13)
end
 %% GSPGL1 (solves   minimize ||x||_{2,1} S.T. ||Ax-y||<=del)
 ff = 'GSPGl1';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     del = norm(y-ye);
     tic,
     opts = spgSetParms('verbosity',0);
     x    = spg_group(X,y,gidx,del,opts);
     timegspgl1 = toc;
     MSE_spgl1=norm(x-xe)^2/n;
     psnrgspgl1 = psnr(x,xe)
     %psnrgspgl1 = -10*log10(norm(x-xe)^2/n)
     Scputime = [Scputime;timegspgl1];
     Spsnr = [Spsnr;psnrgspgl1];
     MSE=[MSE;MSE_spgl1];
      subplot(2,4,8)
     imshow(reshape(x(id),48,48,3),[])
     h = title('SPGl1');
     set(h,'Interpreter','latex','fontsize',13)
     x0=x;
     save x0.mat x0
 end
 %% GCD (solves  Group MCP)
 ff = 'GCD';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     rX = X;
     for kk = 1:max(gidx)
         ind   = find(gidx == kk);
         rX(:,ind) = X(:,ind)*(invXgsqrt{kk} + 0*eye(length(ind)));
     end
     rho  = 'mcp'; % lasso, mcp or scad
     opts = setopts(gidx,invXgsqrt,rho);
     opts.del = norm(ye-y);
     opts.mu = 1;
     tic,
     [x,ithist] = groupcd(rX,y,rho,opts);
     for kk = 1:max(gidx)
         ind   = find(gidx == kk);
          x(ind) = invXgsqrt{kk}*x(ind);
     end
     timegcd = toc;
     MSE_gcd=norm(x-xe)^2/n;
     psnrgcd = psnr(x,xe)
     %psnrgcd = -10*log10(norm(x-xe)^2/n)
     Scputime = [Scputime;timegcd];
     Spsnr = [Spsnr;psnrgcd];
     MSE=[MSE;MSE_gcd];
     subplot(2,4,5)
     imshow(reshape(x(id),48,48,3),[])
     h = title('GCD');
     set(h,'Interpreter','latex','fontsize',13)
 end
 Scputime
 Spsnr
 MSE
 
 %save Scputime102_PSNR.mat Scputime
 %save Spsnr102_PSNR.mat Spsnr
 %save MSE102_PSNR.mat MSE
  %fig01s002 fig1R