clc, clear all, close all
addpath(genpath(fileparts(mfilename('fullpath'))));
FIELDS={'GPDASC','GOMP','GSPGl1','GCD'}; % all available solvers
%%%%%%%%
% Fig 
%%%%%%%%
%----------------------   Generate data  ---------------------------------%
dopts.sigma = 0.03;
dopts.cor = 0;  
dopts.seednum  = 0;
dopts.twodim = 2;
[X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg,out] = gendata([],[],[],[],dopts);
id = [1:3:(64^2-1)*3+1,2:3:(64^2-1)*3+2,3:3:(64^2-1)*3+3]';
Ir = out.I(:,:,1);
Ig = out.I(:,:,2);
Ib = out.I(:,:,3);
scale = max(max(max(out.I))) - min(min(min(out.I)));
Ibar = out.Ibar;
Ibarr = Ibar(1);
Ibarg = Ibar(2);
Ibarb = Ibar(3);
figure(1)
subplot(2,4,1)
imshow(out.I,[])
h = title('Original');
set(h,'Interpreter','latex','fontsize',13)
Scputime = [];
Serror = [];
Spsnr = [];
MSE=[];
L=sum(abs(xe) > 0)
%max(xe)
%min(xe)
%% DC
maxiter1=5000;maxiter2=5000;tol=1e-7;rho=2;deta=10;lambda=0.3;lambda1=0.0004;lambda2=0.004;n=12288;
A=X;b=y;
%Lf=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*b,inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*b),inf)]);
%save Lf.mat Lf
%Ls=2*eigs(A*A',1);
%Ls=2*norm(A'*A);
%save Ls.mat Ls
load Lf.mat
load Ls.mat
v=0.99*min(lambda1/Lf,deta);
cc=Ls/4; alphaB=Ls/4; Unum=1200;

%alg1_1 R1
tic
[x_new_R1,iter_R1,a_R1] = alg1_1b_R1( n, A, b, lambda1, lambda2, alphaB, Unum, deta, v, cc, rho, maxiter1, tol);
Time_R1=toc;
Iter_R1=iter_R1;
x_new=x_new_R1;
MSE_R1=norm(x_new-xe)^2/n;
psnr_R1 = psnr(x_new,xe)
MSE=[MSE;MSE_R1];
Z_R1=sum(abs(x_new) > 0);
fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', Iter_R1, Time_R1, MSE_R1);
fprintf(' Z1 = %3d\n a = %3d\n',  Z_R1,a_R1);
c=x_new;
c = c(id);
cr = c(1:64^2);
cg = c(64^2+1:2*64^2);
cb = c(2*64^2+1:3*64^2);
xr = out.W(reshape(cr,[64 64])) + Ibarr;
xg = out.W(reshape(cg,[64 64])) + Ibarg;
xb = out.W(reshape(cb,[64 64])) + Ibarb;
x2d = zeros(64,64,3);
x2d(:,:,1) = xr;
x2d(:,:,2) = xg;
x2d(:,:,3) = xb;
error_R1 = norm(x2d(:)-out.I(:));
Scputime = [Scputime;Time_R1];
Spsnr = [Spsnr;psnr_R1];
Serror = [Serror;error_R1];
subplot(2,4,2)
imshow(x2d,[])
h = title('Alg.3.1(N=1)');
set(h,'Interpreter','latex','fontsize',13)
%alg1_1 R2
tic
[x_new_R2,iter_R2,a_R2] = alg1_1b_R2( n, A, b, lambda1, lambda2, alphaB, Unum, deta, v, cc, rho, maxiter1, tol);
Time_R2=toc;
Iter_R2=iter_R2;
x_new=x_new_R2;
MSE_R2=norm(x_new-xe)^2/n;
psnr_R2 = psnr(x_new,xe)
MSE=[MSE;MSE_R2];
Z_R2=sum(abs(x_new) > 0);
fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', Iter_R2, Time_R2, MSE_R2);
fprintf(' Z1 = %3d\n a = %3d\n',  Z_R2,a_R2);
c=x_new;
c = c(id);
cr = c(1:64^2);
cg = c(64^2+1:2*64^2);
cb = c(2*64^2+1:3*64^2);
xr = out.W(reshape(cr,[64 64])) + Ibarr;
xg = out.W(reshape(cg,[64 64])) + Ibarg;
xb = out.W(reshape(cb,[64 64])) + Ibarb;
x2d = zeros(64,64,3);
x2d(:,:,1) = xr;
x2d(:,:,2) = xg;
x2d(:,:,3) = xb;
error_R2 = norm(x2d(:)-out.I(:));
Scputime = [Scputime;Time_R2];
Spsnr = [Spsnr;psnr_R2];
Serror = [Serror;error_R2];
subplot(2,4,3)
imshow(x2d,[])
h = title('Alg.3.1(N=2)');
set(h,'Interpreter','latex','fontsize',13)
%alg1_1 R3
tic
[x_new_R3,iter_R3,a_R3] = alg1_1b_R3( n, A, b, lambda1, lambda2, alphaB, Unum, deta, v, cc, rho, maxiter1, tol);
Time_R3=toc;
Iter_R3=iter_R3;
x_new=x_new_R3;
MSE_R3=norm(x_new-xe)^2/n;
psnr_R3 = psnr(x_new,xe)
MSE=[MSE;MSE_R3];
Z_R3=sum(abs(x_new) > 0);
fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', Iter_R3, Time_R3, MSE_R3);
fprintf(' Z1 = %3d\n a = %3d\n',  Z_R3,a_R3);
c=x_new;
c = c(id);
cr = c(1:64^2);
cg = c(64^2+1:2*64^2);
cb = c(2*64^2+1:3*64^2);
xr = out.W(reshape(cr,[64 64])) + Ibarr;
xg = out.W(reshape(cg,[64 64])) + Ibarg;
xb = out.W(reshape(cb,[64 64])) + Ibarb;
x2d = zeros(64,64,3);
x2d(:,:,1) = xr;
x2d(:,:,2) = xg;
x2d(:,:,3) = xb;
error_R3 = norm(x2d(:)-out.I(:));
Scputime = [Scputime;Time_R3];
Spsnr = [Spsnr;psnr_R3];
Serror = [Serror;error_R3];
subplot(2,4,4)
imshow(x2d,[])
h = title('Alg.3.1(N=3)');
set(h,'Interpreter','latex','fontsize',13)
% %%alg2_1
% tic
% [x_new2,iter2] = alg2_1b_R1( n, A, b, Ls, lambda1, lambda2, deta, v, maxiter2, tol);
% Time_ag2=toc;
% Iter_ag2=iter2;
% MSE_ag2=norm(x_new2-xe)^2/n;
% MSE=[MSE;MSE_ag2];
% Z_ag2=sum(abs(x_new2) > 0);
% fprintf(' iter2 = %5.2d  time2 = %5.2f  MSE2 = %3.2d\n', mean(Iter_ag2), mean(Time_ag2), mean(MSE_ag2));
% fprintf(' Z2 = %3d\n',mean(Z_ag2));
% c=x_new2;
% c = c(id);
% cr = c(1:64^2);
% cg = c(64^2+1:2*64^2);
% cb = c(2*64^2+1:3*64^2);
% xr = out.W(reshape(cr,[64 64])) + Ibarr;
% xg = out.W(reshape(cg,[64 64])) + Ibarg;
% xb = out.W(reshape(cb,[64 64])) + Ibarb;
% x2d = zeros(64,64,3);
% x2d(:,:,1) = xr;
% x2d(:,:,2) = xg;
% x2d(:,:,3) = xb;
% psnr2_1 = psnr(out.I,x2d,scale)
% error2 = norm(x2d(:)-out.I(:));
% Scputime = [Scputime;Time_ag2];
% Spsnr = [Spsnr;psnr2_1];
% subplot(2,4,3)
% imshow(x2d,[])
% h = title('Alg.3.2');
% set(h,'Interpreter','latex','fontsize',13)

% %alg1_1 R4
% tic
% [x_new_R4,iter_R4,a_R4] = alg1_1b_R4( n, A, b, lambda1, lambda2, alphaB, Unum, deta, v, cc, rho, maxiter1, tol);
% Time_R4=toc;
% Iter_R4=iter_R4;
% x_new=x_new_R4;
% MSE_R4=norm(x_new-xe)^2/n;
% psnr_R4 = psnr(x_new,xe)
% MSE=[MSE;MSE_R4];
% Z_R4=sum(abs(x_new) > 0);
% fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', Iter_R4, Time_R4, MSE_R4);
% fprintf(' Z1 = %3d\n a = %3d\n',  Z_R4,a_R4);
% c=x_new;
% c = c(id);
% cr = c(1:64^2);
% cg = c(64^2+1:2*64^2);
% cb = c(2*64^2+1:3*64^2);
% xr = out.W(reshape(cr,[64 64])) + Ibarr;
% xg = out.W(reshape(cg,[64 64])) + Ibarg;
% xb = out.W(reshape(cb,[64 64])) + Ibarb;
% x2d = zeros(64,64,3);
% x2d(:,:,1) = xr;
% x2d(:,:,2) = xg;
% x2d(:,:,3) = xb;
% error_R4 = norm(x2d(:)-out.I(:));
% Scputime = [Scputime;Time_R4];
% Spsnr = [Spsnr;psnr_R4];
% Serror = [Serror;error_R4];
% subplot(2,4,2)
% imshow(x2d,[])
% h = title('Alg.3.1(N=4)');
% set(h,'Interpreter','latex','fontsize',13)
% %alg1_1 R5
% tic
% [x_new_R5,iter_R5,a_R5] = alg1_1b_R5( n, A, b, lambda1, lambda2, alphaB, Unum, deta, v, cc, rho, maxiter1, tol);
% Time_R5=toc;
% Iter_R5=iter_R5;
% x_new=x_new_R5;
% MSE_R5=norm(x_new-xe)^2/n;
% psnr_R5 = psnr(x_new,xe)
% MSE=[MSE;MSE_R5];
% Z_R5=sum(abs(x_new) > 0);
% fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', Iter_R5, Time_R5, MSE_R5);
% fprintf(' Z1 = %3d\n a = %3d\n',  Z_R5,a_R5);
% c=x_new;
% c = c(id);
% cr = c(1:64^2);
% cg = c(64^2+1:2*64^2);
% cb = c(2*64^2+1:3*64^2);
% xr = out.W(reshape(cr,[64 64])) + Ibarr;
% xg = out.W(reshape(cg,[64 64])) + Ibarg;
% xb = out.W(reshape(cb,[64 64])) + Ibarb;
% x2d = zeros(64,64,3);
% x2d(:,:,1) = xr;
% x2d(:,:,2) = xg;
% x2d(:,:,3) = xb;
% error_R5 = norm(x2d(:)-out.I(:));
% Scputime = [Scputime;Time_R5];
% Spsnr = [Spsnr;psnr_R5];
% Serror = [Serror;error_R5];
% subplot(2,4,2)
% imshow(x2d,[])
% h = title('Alg.3.1(N=5)');
% set(h,'Interpreter','latex','fontsize',13)

%% GPDASC (solves  min lambda*||x||_{2,0} + 1/2 ||Ax-y||_^2)
fid = 1;
 printf = @(varargin) fprintf(fid,varargin{:});
 ff = 'GPDASC';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     % set parameters
     opts = setopts(gidx,invXgsqrt,'gpdas');
     opts.scale = 1;
     opts.del = norm(y-ye);
     opts.alpha = 0;
     opts.Lmin = 1e-10;
     tic, 
     [c,lam,ithist,A] = grouppdas(X,Xt,y,opts);
     timegpdasc = toc
     MSE_gpdasc=norm(c-xe)^2/n;
     psnrgpdasc = psnr(c,xe)
     MSE=[MSE;MSE_gpdasc];
     c = c(id);
     cr = c(1:64^2);
     cg = c(64^2+1:2*64^2);
     cb = c(2*64^2+1:3*64^2);
     xr = out.W(reshape(cr,[64 64])) + Ibarr;
     xg = out.W(reshape(cg,[64 64])) + Ibarg;
     xb = out.W(reshape(cb,[64 64])) + Ibarb;
     x2d = zeros(64,64,3);
     x2d(:,:,1) = xr;
     x2d(:,:,2) = xg;
     x2d(:,:,3) = xb;
     Scputime = [Scputime;timegpdasc];
     Spsnr = [Spsnr;psnrgpdasc];
     error = norm(x2d(:)-out.I(:));
     Serror = [Serror;error];
     subplot(2,4,6)
     imshow(x2d,[])
     h = title('GPDASC');
     set(h,'Interpreter','latex','fontsize',13)
 end
%% OMP
ff = 'GOMP';
 if ismember(ff,FIELDS)
    printf('\n-- %s, at %s --\n',ff,datestr(now));
    tic,
    opts = setopts(gidx,invXgsqrt,'gomp');
    opts.del = norm(ye-y);
    opts.alpha = 0;
    c = groupomp(X,Xt,y,opts);
    timegomp = toc
    MSE_gomp=norm(c-xe)^2/n;
    psnrgomp = psnr(c,xe)
    MSE=[MSE;MSE_gomp];
    c = c(id);
    cr = c(1:64^2);
     cg = c(64^2+1:2*64^2);
     cb = c(2*64^2+1:3*64^2);
     xr = out.W(reshape(cr,[64 64]))+Ibarr;
     xg = out.W(reshape(cg,[64 64]))+Ibarg;
     xb = out.W(reshape(cb,[64 64]))+Ibarb;
     x2d = zeros(64,64,3);
     x2d(:,:,1) = xr;
     x2d(:,:,2) = xg;
     x2d(:,:,3) = xb;
     Scputime = [Scputime;timegomp];
     Spsnr = [Spsnr;psnrgomp];
     error = norm(x2d(:)-out.I(:));
     Serror = [Serror;error];
     subplot(2,4,7)
     imshow(x2d,[])
     h = title('GOMP');
     set(h,'Interpreter','latex','fontsize',13)
end
 %% GSPGL1 (solves   minimize ||x||_{2,1} S.T. ||Ax-y||<=del)
 ff = 'GSPGl1';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     del = norm(y-ye);
     tic,
     opts = spgSetParms('verbosity',0);
     c    = spg_group(X,y,gidx,del,opts);
     timegspgl1 = toc
     MSE_spgl1=norm(c-xe)^2/n;
     psnrgspgl1 = psnr(c,xe)
     MSE=[MSE;MSE_spgl1];
     c = c(id);
     cr = c(1:64^2);
     cg = c(64^2+1:2*64^2);
     cb = c(2*64^2+1:3*64^2);
     xr = out.W(reshape(cr,[64 64]))+Ibarr;
     xg = out.W(reshape(cg,[64 64]))+Ibarg;
     xb = out.W(reshape(cb,[64 64]))+Ibarb;
     x2d = zeros(64,64,3);
     x2d(:,:,1) = xr;
     x2d(:,:,2) = xg;
     x2d(:,:,3) = xb;
     Scputime = [Scputime;timegspgl1];
     Spsnr = [Spsnr;psnrgspgl1]; 
     error = norm(x2d(:)-out.I(:));
     Serror = [Serror;error];
     subplot(2,4,8)
     imshow(x2d)
     h = title('SPGl1');
     set(h,'Interpreter','latex','fontsize',13)
 end
 %% GCD (solves  Group MCP)
 ff = 'GCD';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     rX = X;
     for kk = 1:max(gidx)
         ind   = find(gidx == kk);
         rX(:,ind) = X(:,ind)*(invXgsqrt{kk} + 0*eye(length(ind)));
     end
     rho  = 'mcp'; % lasso, mcp or scad
     opts = setopts(gidx,invXgsqrt,rho);
     opts.del = norm(ye-y);
     opts.mu = 0.5;
     tic,
     [c,ithist] = groupcd(rX,y,rho,opts);
     for kk = 1:max(gidx)
         ind   = find(gidx == kk);
          c(ind) = invXgsqrt{kk}*c(ind);
     end
     timegcd = toc
     MSE_gcd=norm(c-xe)^2/n;
     psnrgcd = psnr(c,xe)
     MSE=[MSE;MSE_gcd];
     c = c(id);
     cr = c(1:64^2);
     cg = c(64^2+1:2*64^2);
     cb = c(2*64^2+1:3*64^2);
     xr = out.W(reshape(cr,[64 64]))+Ibarr;
     xg = out.W(reshape(cg,[64 64]))+Ibarg;
     xb = out.W(reshape(cb,[64 64]))+Ibarb;
     x2d = zeros(64,64,3);
     x2d(:,:,1) = xr;
     x2d(:,:,2) = xg;
     x2d(:,:,3) = xb;
     Scputime = [Scputime;timegcd];
     Spsnr = [Spsnr;psnrgcd]; 
     error = norm(x2d(:)-out.I(:));
     Serror = [Serror;error];
     subplot(2,4,5)
     imshow(x2d,[])
     h = title('GCD');
     set(h,'Interpreter','latex','fontsize',13)
 end
 Scputime
 Spsnr
 MSE
 Serror

 %save Scputime201_PSNR.mat Scputime
 %save Spsnr201_PSNR.mat Spsnr
 %save MSE201_PSNR.mat MSE
 %fig02s002 %fig2R