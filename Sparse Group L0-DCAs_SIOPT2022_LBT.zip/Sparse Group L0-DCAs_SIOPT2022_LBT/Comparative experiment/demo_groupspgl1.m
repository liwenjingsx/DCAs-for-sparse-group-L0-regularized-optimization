% demo script for spgl1
clc, clear, close all
addpath(genpath(fileparts(mfilename('fullpath'))));
%% Generate data;
p = 2000;             % length of solution  
n = 500;              % number of samples
Ks = 500;
dopts.sigma = 0.01;
dopts.cor = 5;   
dopts.ratio = 2;
Kg = 50;
dopts.seednum  = 0;
[X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata(n,p,Ks,Kg,dopts);

%% group SPGL1
disp('SPGL1 for Group base pursuit denoising is running')

del = norm(y-ye);
tic,
opts = spgSetParms('verbosity',1);
x    = spg_group(X,y,gidx,del,opts);
toc
rel2err = norm(x - xe)/norm(xe);
abslinferr = norm(x- xe,inf);
A = findgsupp(x,gidx);
Ap = length(setdiff(suppg,A));
Am = length(setdiff(A,suppg));
display(['|A \ A^*| = ' num2str(Ap) '   |A^* \ A| = ' num2str(Am)])
display(sprintf(' #  ral l_2 error = %g, abs l_inf error = %g',rel2err, abslinferr))
figure(1), plot(1:p,xe,'ko',1:p,x,'r*'),
h = title('GroupSPGL1, xe  (o) and x   (*)');
set(h,'Interpreter','latex','fontsize',13)