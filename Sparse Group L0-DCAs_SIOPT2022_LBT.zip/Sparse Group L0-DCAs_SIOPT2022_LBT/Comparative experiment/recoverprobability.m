clc, clear all, close all
addpath(genpath(fileparts(mfilename('fullpath'))));
FIELDS={'GPDASC','GOMP','GSPGl1','GCD'}; % all available solvers; % all available solvers
for fig = 1:2
    %%%%%%%%
    % Fig
    %%%%%%%%
    if fig == 1
        %----------------------   Generate data  ---------------------------------%
        p = 2000;             % length of solution
        n = 800;              % number of samples
        Ks = 500;
        dopts.sigma = 0.001;
        dopts.cor = 0;
        dopts.ratio = 1;
        maxnumtest = 100;      % number of realizations
        nmethod = 4;
        SparseLev = 10:10:100;
        len = length(SparseLev);
        Scputime = zeros(maxnumtest,len,nmethod);
        Srel2error = zeros(maxnumtest,len,nmethod);
        Sabslinferror = zeros(maxnumtest,len,nmethod);
        Sstopiternum = zeros(maxnumtest,len,nmethod);
        Ssignificant = zeros(maxnumtest,len,nmethod);
        Sexact  = zeros(maxnumtest,len,nmethod);
        dopts.seednum = 0;
        for k = 1:len
            Kg = SparseLev(k);
            for l = 1:maxnumtest
                dopts.seednum = dopts.seednum + k*l;        % seed number
                [X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata(n,p,Ks,Kg,dopts);
                fid = 1;
                %% GPDASC(solves  min lambda*||x||_{2,0} + 1/2 ||Ax-y||_^2)
                ff = 'GPDASC';
                printf = @(varargin) fprintf(fid,varargin{:});
                if ismember(ff,FIELDS)
                    printf('\n-- %s, at %s --\n',ff,datestr(now));
                    % set parameters
                    opts = setopts(gidx,invXgsqrt,'gpdas');
                    opts.scale = 1;
                    opts.del = norm(y-ye);
                    opts.alpha = 0;
                    tic,
                    [x,lam,ithist,A] = grouppdas(X,Xt,y,opts);
                    mm = 1;
                    Scputime(l,k,mm) = toc;
                    Srel2error(l,k,mm) =  norm(x - xe)/norm(xe);
                    Sabslinferror(l,k,mm) = norm(x - xe,inf);
                    eA = A;
                    Ae = suppg;
                    if isempty(setdiff(Ae,eA))
                        Ssignificant(l,k,mm) = 1;
                    end
                    if length(eA) == length(Ae)
                        if eA == Ae
                            Sexact(l,k,mm) = 1;
                        end
                    end
                end
                %% OMP
                ff = 'GOMP';
                if ismember(ff,FIELDS)
                    printf('\n-- %s, at %s --\n',ff,datestr(now));
                    tic,
                    opts = setopts(gidx,invXgsqrt,'gomp');
                    opts.del = 1*norm(ye-y);
                    opts.alpha = 0*1e-8;
                    x  = groupomp(X,Xt,y,opts);
                    eA = findgsupp(x,gidx);
                    mm = 2;
                    Scputime(l,k,mm) = toc;
                    Srel2error(l,k,mm) =  norm(x - xe)/norm(xe);
                    Sabslinferror(l,k,mm) = norm(x - xe,inf);
                    Ae = suppg;
                    if isempty(setdiff(Ae,eA))
                        Ssignificant(l,k,mm) = 1;
                    end
                    if length(eA) == length(Ae)
                        if sort(eA) == Ae
                            Sexact(l,k,mm) = 1;
                        end
                    end
                end
                %% GSPGL1 (solves   minimize ||x||_{2,1} S.T. ||Ax-y||<=del)
                ff = 'GSPGl1';
                if ismember(ff,FIELDS)
                    printf('\n-- %s, at %s --\n',ff,datestr(now));
                    del = norm(y-ye);
                    tic,
                    opts = spgSetParms('verbosity',0);
                    x    = spg_group(X,y,gidx,del,opts);
                    mm = 3;
                    Scputime(l,k,mm) = toc;
                    Srel2error(l,k,mm) =  norm(x - xe)/norm(xe);
                    Sabslinferror(l,k,mm) = norm(x - xe,inf);
                    eA = findgsupp(x,gidx);
                    Ae = suppg;
                    if isempty(setdiff(Ae,eA))
                        Ssignificant(l,k,mm) = 1;
                    end
                    if length(eA) == length(Ae)
                        if sort(eA) == Ae
                            Sexact(l,k,mm) = 1;
                        end
                    end
                end
                %% GCD (solves  Group MCP)
                ff = 'GCD';
                if ismember(ff,FIELDS)
                    printf('\n-- %s, at %s --\n',ff,datestr(now));
                    rX = X;
                    for kk = 1:max(gidx)
                        ind   = find(gidx == kk);
                        rX(:,ind) = X(:,ind)*(invXgsqrt{kk} + 0*eye(length(ind)));
                    end
                    rho  = 'mcp'; % lasso, mcp or scad
                    opts = setopts(gidx,invXgsqrt,rho);
                    opts.del = 1*norm(ye-y);
                    opts.mu = 1;
                    tic,
                    [x,ithist] = groupcd(rX,y,rho,opts);
                    for kk = 1:max(gidx)
                        ind   = find(gidx == kk);
                        x(ind) = invXgsqrt{kk}*x(ind);
                    end
                    mm = 4;
                    Scputime(l,k,mm) = toc;
                    Srel2error(l,k,mm) =  norm(x - xe)/norm(xe);
                    Sabslinferror(l,k,mm) = norm(x - xe,inf);
                    eA = findgsupp(x,gidx);
                    Ae = suppg;
                    if isempty(setdiff(Ae,eA))
                        Ssignificant(l,k,mm) = 1;
                    end
                    if length(eA) == length(Ae)
                        if sort(eA) == Ae
                            Sexact(l,k,mm) = 1;
                        end
                    end
                end
            end
        end
        %% Compute average performance
        averagetime = mean(Scputime);
        stdtime = std(Scputime);
        averagerel2error = mean(Srel2error);
        stdl2error = std(Srel2error);
        averageabslinferror = mean(Sabslinferror);
        stdabslinferror = std(Sabslinferror);
        proboracle = mean(Sexact);
        probsignif = mean(Ssignificant);
        %% plot results
        figure(1),
        N = SparseLev;
        prob = [proboracle(:,:,1);proboracle(:,:,2);proboracle(:,:,3);proboracle(:,:,4)]';
        plot(N,prob(:,1),'kd-',N,prob(:,2),'b*:',N,prob(:,3),'ro--',N,prob(:,4),'gs:', 'LineWidth',1.3)
        h = xlabel(' $T$');
        set(h,'Interpreter','latex','fontsize',13)
        h = ylabel('Probability');
        set(h,'Interpreter','latex','fontsize',13)
        h = legend('GPDASC','GOMP','SPGl1','GCD',4);
        set(h,'Interpreter','latex','fontsize',13)
        axis([0 1.2*max(N) -0.2 1.5])
    else
        %%%%%%%%
        % Fig
        %%%%%%%%
        %----------------------   Generate data  ---------------------------------%
        p = 2000;             % length of solution
        n = 800;              % number of samples
        Ks = 500;
        dopts.sigma = 0.001;
        dopts.cor = 3;
        dopts.ratio = 1;
        maxnumtest = 100;      % number of realizations
        nmethod = 4;
        SparseLev = 10:20:150;
        len = length(SparseLev);
        Scputime = zeros(maxnumtest,len,nmethod);
        Srel2error = zeros(maxnumtest,len,nmethod);
        Sabslinferror = zeros(maxnumtest,len,nmethod);
        Sstopiternum = zeros(maxnumtest,len,nmethod);
        Ssignificant = zeros(maxnumtest,len,nmethod);
        Sexact  = zeros(maxnumtest,len,nmethod);
        dopts.seednum = 0;
        
        for k = 1:len
            Kg = SparseLev(k);
            for l = 1:maxnumtest
                dopts.seednum = dopts.seednum + k*l;        % seed number
                [X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata(n,p,Ks,Kg,dopts);
                fid = 1;
                %% GPDASC(solves  min lambda*||x||_{2,0} + 1/2 ||Ax-y||_^2)
                ff = 'GPDASC';
                printf = @(varargin) fprintf(fid,varargin{:});
                if ismember(ff,FIELDS)
                    printf('\n-- %s, at %s --\n',ff,datestr(now));
                    % set parameters
                    opts = setopts(gidx,invXgsqrt,'gpdas');
                    opts.scale = 1;
                    opts.del = norm(y-ye);
                    tic,
                    [x,lam,ithist,A] = grouppdas(X,Xt,y,opts);
                    mm = 1;
                    Scputime(l,k,mm) = toc;
                    Srel2error(l,k,mm) =  norm(x - xe)/norm(xe);
                    Sabslinferror(l,k,mm) = norm(x - xe,inf);
                    eA = A;
                    Ae = suppg;
                    if isempty(setdiff(Ae,eA))
                        Ssignificant(l,k,mm) = 1;
                    end
                    if length(eA) == length(Ae)
                        if eA == Ae
                            Sexact(l,k,mm) = 1;
                        end
                    end
                end
                %% OMP
                ff = 'GOMP';
                if ismember(ff,FIELDS)
                    printf('\n-- %s, at %s --\n',ff,datestr(now));
                    tic,
                    opts = setopts(gidx,invXgsqrt,'gomp');
                    opts.del = 1*norm(ye-y);
                    opts.alpha = 0*1e-8;
                    x  = groupomp(X,Xt,y,opts);
                    eA = findgsupp(x,gidx);
                    mm = 2;
                    Scputime(l,k,mm) = toc;
                    Srel2error(l,k,mm) =  norm(x - xe)/norm(xe);
                    Sabslinferror(l,k,mm) = norm(x - xe,inf);
                    Ae = suppg;
                    if isempty(setdiff(Ae,eA))
                        Ssignificant(l,k,mm) = 1;
                    end
                    if length(eA) == length(Ae)
                        if sort(eA) == Ae
                            Sexact(l,k,mm) = 1;
                        end
                    end
                end
                %% GSPGL1 (solves   minimize ||x||_{2,1} S.T. ||Ax-y||<=del)
                ff = 'GSPGl1';
                if ismember(ff,FIELDS)
                    printf('\n-- %s, at %s --\n',ff,datestr(now));
                    del = norm(y-ye);
                    tic,
                    opts = spgSetParms('verbosity',0);
                    x    = spg_group(X,y,gidx,del,opts);
                    mm = 3;
                    Scputime(l,k,mm) = toc;
                    Srel2error(l,k,mm) =  norm(x - xe)/norm(xe);
                    Sabslinferror(l,k,mm) = norm(x - xe,inf);
                    eA = findgsupp(x,gidx);
                    Ae = suppg;
                    if isempty(setdiff(Ae,eA))
                        Ssignificant(l,k,mm) = 1;
                    end
                    if length(eA) == length(Ae)
                        if sort(eA) == Ae
                            Sexact(l,k,mm) = 1;
                        end
                    end
                end
                %% GCD (solves  Group MCP)
                ff = 'GCD';
                if ismember(ff,FIELDS)
                    printf('\n-- %s, at %s --\n',ff,datestr(now));
                    rX = X;
                    for kk = 1:max(gidx)
                        ind   = find(gidx == kk);
                        rX(:,ind) = X(:,ind)*(invXgsqrt{kk} + 0*eye(length(ind)));
                    end
                    rho  = 'mcp'; % lasso, mcp or scad
                    opts = setopts(gidx,invXgsqrt,rho);
                    opts.del = 1*norm(ye-y);
                    opts.mu = 1;
                    tic,
                    [x,ithist] = groupcd(rX,y,rho,opts);
                    for kk = 1:max(gidx)
                        ind   = find(gidx == kk);
                        x(ind) = invXgsqrt{kk}*x(ind);
                    end
                    mm = 4;
                    Scputime(l,k,mm) = toc;
                    Srel2error(l,k,mm) =  norm(x - xe)/norm(xe);
                    Sabslinferror(l,k,mm) = norm(x - xe,inf);
                    eA = findgsupp(x,gidx);
                    Ae = suppg;
                    if isempty(setdiff(Ae,eA))
                        Ssignificant(l,k,mm) = 1;
                    end
                    if length(eA) == length(Ae)
                        if sort(eA) == Ae
                            Sexact(l,k,mm) = 1;
                        end
                    end
                end
            end
        end
        %% Compute average performance
        averagetime = mean(Scputime);
        stdtime = std(Scputime);
        averagerel2error = mean(Srel2error);
        stdl2error = std(Srel2error);
        averageabslinferror = mean(Sabslinferror);
        stdabslinferror = std(Sabslinferror);
        proboracle = mean(Sexact);
        probsignif = mean(Ssignificant);
        %% plot results
        figure(2),
        N = SparseLev;
        prob = [proboracle(:,:,1);proboracle(:,:,2);proboracle(:,:,3);proboracle(:,:,4)]';
        plot(N,prob(:,1),'kd-',N,prob(:,2),'b*:',N,prob(:,3),'ro--',N,prob(:,4),'gs:', 'LineWidth',1.3)
        h = xlabel(' $T$');
        set(h,'Interpreter','latex','fontsize',13)
        h = ylabel('Probability');
        set(h,'Interpreter','latex','fontsize',13)
        h = legend('GPDASC','GOMP','SPGl1','GCD',13);
        set(h,'Interpreter','latex','fontsize',13)
        axis([0 1.2*max(N) -0.2 1.5])
    end
end