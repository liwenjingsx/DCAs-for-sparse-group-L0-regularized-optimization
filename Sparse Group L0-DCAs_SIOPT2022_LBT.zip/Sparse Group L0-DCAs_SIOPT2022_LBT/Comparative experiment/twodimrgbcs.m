clc, clear all, close all
addpath(genpath(fileparts(mfilename('fullpath'))));
FIELDS={'GPDASC','GOMP','GSPGl1','GCD'}; % all available solvers
%%%%%%%%
% Fig 
%%%%%%%%
%----------------------   Generate data  ---------------------------------%
dopts.sigma = 0.1;
dopts.cor = 10;   
dopts.seednum  = 0;
dopts.twodim = 1;
[X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata([],[],[],[],dopts);
id = [1:3:(48^2-1)*3+1,2:3:(48^2-1)*3+2,3:3:(48^2-1)*3+3]';
figure(1)
subplot(2,3,1)
imshow(reshape(xe(id),48,48,3),[])
h = title('Original');
set(h,'Interpreter','latex','fontsize',13)
Scputime = [];
Spsnr = [];
%% GPDASC (solves  min lambda*||x||_{2,0} + 1/2 ||Ax-y||_^2)
fid = 1;
 printf = @(varargin) fprintf(fid,varargin{:});
 ff = 'GPDASC';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     % set parameters
     opts = setopts(gidx,invXgsqrt,'gpdas');
     opts.scale = 1;
     opts.del = norm(y-ye);
     opts.alpha = 0;
     opts.Lmin = 1e-15;
     tic, 
     [x,lam,ithist,A] = grouppdas(X,Xt,y,opts);
     timegpdasc = toc
     psnrgpdasc = mpsnr(x,xe);
     Scputime = [Scputime;timegpdasc];
     Spsnr = [Spsnr;psnrgpdasc];
     subplot(2,3,2)
     imshow(reshape(x(id),48,48,3),[])
     h = title('GPDASC');
     set(h,'Interpreter','latex','fontsize',13)
 end
%% OMP
ff = 'GOMP';
 if ismember(ff,FIELDS)
    printf('\n-- %s, at %s --\n',ff,datestr(now));
    tic,
    opts = setopts(gidx,invXgsqrt,'gomp');
    opts.del = norm(ye-y);
    opts.alpha = 0;
    x = groupomp(X,Xt,y,opts);
    timegomp = toc
     psnrgomp = mpsnr(x,xe);
     Scputime = [Scputime;timegomp];
     Spsnr = [Spsnr;psnrgomp];
      subplot(2,3,3)
     imshow(reshape(x(id),48,48,3),[])
     h = title('GOMP');
     set(h,'Interpreter','latex','fontsize',13)
end
 %% GSPGL1 (solves   minimize ||x||_{2,1} S.T. ||Ax-y||<=del)
 ff = 'GSPGl1';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     del = norm(y-ye);
     tic,
     opts = spgSetParms('verbosity',0);
     x    = spg_group(X,y,gidx,del,opts);
     timegspgl1 = toc
     psnrgspgl1 = mpsnr(x,xe);
     Scputime = [Scputime;timegspgl1];
     Spsnr = [Spsnr;psnrgspgl1];
      subplot(2,3,4)
     imshow(reshape(x(id),48,48,3),[])
     h = title('SPGl1');
     set(h,'Interpreter','latex','fontsize',13)
 end
 %% GCD (solves  Group MCP)
 ff = 'GCD';
 if ismember(ff,FIELDS)
     printf('\n-- %s, at %s --\n',ff,datestr(now));
     rX = X;
     for kk = 1:max(gidx)
         ind   = find(gidx == kk);
         rX(:,ind) = X(:,ind)*(invXgsqrt{kk} + 0*eye(length(ind)));
     end
     rho  = 'mcp'; % lasso, mcp or scad
     opts = setopts(gidx,invXgsqrt,rho);
     opts.del = norm(ye-y);
     opts.mu = 1;
     tic,
     [x,ithist] = groupcd(rX,y,rho,opts);
     for kk = 1:max(gidx)
         ind   = find(gidx == kk);
          x(ind) = invXgsqrt{kk}*x(ind);
     end
     timegcd = toc
     psnrgcd = mpsnr(x,xe);
     Scputime = [Scputime;timegcd];
     Spsnr = [Spsnr;psnrgcd];
     subplot(2,3,5)
     imshow(reshape(x(id),48,48,3),[])
     h = title('GCD');
     set(h,'Interpreter','latex','fontsize',13)
 end
 Scputime
 Spsnr
    