% demo for group OMP

clc, clear, close all
addpath(genpath(fileparts(mfilename('fullpath'))));
%% Generate data;
p = 2000;             % length of solution  
n = 500;              % number of samples
Ks = 500;
dopts.sigma = 0.01;
dopts.cor = 5;   
dopts.ratio = 1;
Kg = 50;
dopts.seednum  = 0;
[X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata(n,p,Ks,Kg,dopts);

%% --------------------GOMP-----------------------%
opts = setopts(gidx,invXgsqrt,'gomp');
opts.del = 1*norm(ye-y);
opts.alpha = 0*1e-8;
tic,
x  = groupomp(X,Xt,y,opts);
toc
A = findgsupp(x,gidx);
Ap = length(setdiff(suppg,A));
Am = length(setdiff(A,suppg));
display(['|A \ A^*| = ' num2str(Ap) '   |A^* \ A| = ' num2str(Am)])
rel2err = norm(x - xe)/norm(xe);
abslinferr = norm(x- xe,inf);
display(sprintf('rel l_2 error = %g, abs l_inf error = %g',rel2err, abslinferr))
figure(1), plot(1:p,xe,'ko',1:p,x,'r*'),
h = title('Group OMP, xe  (o) and x   (*)');
set(h,'Interpreter','latex','fontsize',13)