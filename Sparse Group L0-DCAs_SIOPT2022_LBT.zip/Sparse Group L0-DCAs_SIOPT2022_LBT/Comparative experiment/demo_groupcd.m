% demo for group coordinate descent (with reorthonormalization)

clc, clear, close all
addpath(genpath(fileparts(mfilename('fullpath'))));

%% Generate data;
p = 2000;             % length of solution  
n = 500;              % number of samples
Ks = 500;
dopts.sigma = 0.01;
dopts.cor = 5;   
dopts.ratio = 1;
Kg = 50;
dopts.seednum  = 0;
[X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata(n,p,Ks,Kg,dopts);

%----------------------- reorthogonalization------------------------------%
reorth = 1;
if reorth == 1
    for k = 1:max(gidx)
        ind   = find(gidx == k);
        X(:,ind) = X(:,ind)*(invXgsqrt{k} + 0*eye(length(ind)));
    end
end

%% --------------------coordinate descent-----------------------%
rho  = 'mcp'; % lasso, mcp or scad
opts = setopts(gidx,invXgsqrt,rho);
opts.del = 1*norm(ye-y);
opts.mu = 1 ;
tic,
[x,ithist] = groupcd(X,y,rho,opts);
toc
if reorth == 1
    for k = 1:max(gidx)
        ind   = find(gidx == k);
        x(ind) = invXgsqrt{k}*x(ind);
    end
end

A = ithist.suppxg;
Ap = length(setdiff(suppg,A));
Am = length(setdiff(A,suppg));
display(['|A \ A^*| = ' num2str(Ap) '   |A^* \ A| = ' num2str(Am)])
rel2err = norm(x - xe)/norm(xe);
abslinferr = norm(x- xe,inf);
display(['rel l_2 error = ' num2str(rel2err) '  abs l_inf error = ',num2str(abslinferr)])
figure(1), plot(1:p,xe,'ko',1:p,x,'r*'),
h = title('Group coordinate descent, xe  (o) and x   (*)');
set(h,'Interpreter','latex','fontsize',13)