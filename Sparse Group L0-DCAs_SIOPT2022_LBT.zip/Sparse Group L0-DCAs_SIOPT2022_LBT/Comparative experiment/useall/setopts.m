function opts = setopts(gidx,invXgsqrt,alg)
%--------------------------------------------------------------------%
% set the default parameters for the algorithm (grouphtp/grouppdas   %
% grouplasso/mcp/scad                                                %
%--------------------------------------------------------------------%
% (c) by Bangti Jin (bangti.jin@gmail.com)                           %
%    and Yuling Jiao (yulingjiaomath@whu.edu.cn)                     %
% Created on 1 June, 2015                                            %
%  modified on Sept. 4, 2015                                         %
%====================================================================%
if nargin < 3
    alg = 'gpdas';
end
if nargin < 2
    error('Not enough inputs in setopts!');
end
opts.gidx = gidx;  % indices for each group
opts.invXgsqrt= invXgsqrt; % group normalization matrix 

switch alg
    case 'gpdas'
        opts.N     = 100;         % # of parameters
        opts.Lmax  = 1;           % largest Lambda
        opts.Lmin  = 1e-8;        % smallest Lambda
        opts.MaxIt = 5;           % maximum number of inner iters
        opts.mu    = 0.5;         % sparsity threshold
        opts.del   = 0;           % unknown noise level
        opts.normpd= [];          % normalized primal-dual sum
        opts.scale = 1;           % 1 for orthonormal.,  0 for naive
        opts.cgtol = 1e-5;        % tolerance for CG iters
        opts.alpha = 1e-7;        % stable parameter
    case 'ghtp'
        opts.MaxIt = 100;         % max. number of inner iters
        opts.cgtol = 1e-5;        % tolerance for CG iters
        opts.scale = 0;           % 1 for orthonormal., 0 for naive
        opts.alpha = 1e-7;        % parameter for stable
        opts.del   = 0;           % unknown noise level
    case 'gomp'
        opts.MaxIt = 1000;         % max. number of inner iters
        opts.cgtol = 1e-5;        % tolerance for CG iters
        opts.scale = 0;           % 1 for orthonormal., 0 for naive
        opts.alpha = 1e-7;        % parameter for stable
        opts.del   = 0;           % unknown noise level
    case 'lasso'
        opts.tau   = 0;           % concavity parameter
        opts.MaxIt = 50;          % maximum # of iterates
        opts.tol   = 1e-5;        % tolerance (relative)
        opts.N     = 100;         % # of parameters
        opts.Lmax  = 1;           % largest Lambda
        opts.Lmin  = 1e-8;        % smallest Lambda
        opts.del   = 0;           % unknown noise level
        opts.mu    = 0.5;         % sparsity threshold
    case 'mcp'
        opts.tau   = 2;           %  concavity parameter
        opts.MaxIt = 50;          % maximum # of iterates
        opts.tol   = 1e-5;        % tolerance (relative)
        opts.N     = 100;         % # of parameters
        opts.Lmax  = 1;           % largest Lambda
        opts.Lmin  = 1e-8;        % smallest Lambda
        opts.del   = 0;           % unknown noise level
        opts.mu    = 0.5;         % sparsity threshold
    case 'scad'
        opts.tau   = 3;           % concavity parameter 
        opts.MaxIt = 50;          % maximum # of iterates
        opts.tol   = 1e-5;        % tolerance (relative)
        opts.N     = 100;         % # of parameters
        opts.Lmax  = 1;           % largest Lambda
        opts.Lmin  = 1e-8;        % smallest Lambda
        opts.del   = 0;           % unknown noise level
        opts.mu    = 0.5;         % sparsity threshold
    otherwise
        error('Unknown option in setopts')
end