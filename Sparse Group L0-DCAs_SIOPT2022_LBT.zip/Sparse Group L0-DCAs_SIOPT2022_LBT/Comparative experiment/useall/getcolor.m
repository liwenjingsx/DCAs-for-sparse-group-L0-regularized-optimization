function cI = getcolor(imagesize)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%��This Program get a color phantom image of size imagesize*imagesize     %          
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------------------------------------------------------------------%
% (c) by Bangti Jin (bangti.jin@gmail.com)                               %
%    and Yuling Jiao (yulingjiaomath@whu.edu.cn)                         %
% Created on 1 June, 2016                                                %
%========================================================================%
imt = phantom(imagesize)*255; % the value of  phantom in  [0,1];
load('colorim.mat');
ims = colorim;
imt(:,:,2) = imt(:,:,1);
imt(:,:,3) = imt(:,:,1);
% Converting to ycbcr color space
nspace1 = rgb2ycbcr(ims);
nspace2 = rgb2ycbcr(imt);
ms = double(nspace1(:,:,1));
mt = double(nspace2(:,:,1));
m1 = max(max(ms));
m2 = min(min(ms));
m3 = max(max(mt));
m4 = min(min(mt));
d1 = m1-m2;
d2 = m3-m4;
% Normalization
dx1 = ms;
dx2 = mt;
dx1 =(dx1*255)/(255-d1);
dx2 = (dx2*255)/(255-d2);
[mx,my,mz] = size(dx2);
% Luminance Comparison
for i = 1:mx
    for j = 1:my
        iy=dx2(i,j);
        tmp=abs(dx1-iy);
        ck=min(min(tmp));
        [r,c] = find(tmp==ck);
        ck=isempty(r);
        if (ck~=1)
            nimage(i,j,2)=nspace1(r(1),c(1),2);
            nimage(i,j,3)=nspace1(r(1),c(1),3);
            nimage(i,j,1)=nspace2(i,j,1);
        end
    end
end
cI = double(ycbcr2rgb(nimage))/255;
end