function eA = findgsupp(x,gidx)
%------------------------------------------------------------------%
% find the group support of x                                      %
%------------------------------------------------------------------%

eA = zeros(max(gidx),1);
s = 1;
for kk = 1:max(gidx)
    ind = find(gidx == kk);
    if norm(x(ind)) > 0 %#ok<FNDSB>
        eA(s) =  kk;
        s = s+1;
    end
end
eA = eA(1:s-1);
