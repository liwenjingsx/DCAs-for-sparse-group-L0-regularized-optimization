function [X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg,out] =   gendata(n,p,Ks,Kg,opts)
%========================================================================%
% INPUTS:                                                                %
%         n   ---- number of samples                                     %
%         p   ---- signal length                                         %
%         Ks  ---- number of  groups in the signal                       %
%         Kg  ---- number of nonzero groups in the signal                %
%   opts --- structure containing                                        %
%        cor  ---- correlation within groups    (default 0)              %
%      ratio  ---- range of value in the signal (= 10^ratio) (default: 0)%
%      sigma  ---- noise variance (default: .1)                          %
%     seednum ---- seed number  (default 0)                              %
%       gsize ---- a integer vector of length Kg contains sizes of g_i   %
%                  with min(gsize) > 2 (default [], for equal group size)%
% matrixtype  ---- type of sample matirx                                 %
%          'gauss'   (defaul)                                            %
%          'bernoulli'                                                   %
%          'partdct'
%     isnorm  ---- normalization after adding correlation (default: 1)   %
%     twodim  ---- two dimensional cs image problem, 0 for 1dim problem  % 
%                  1 for 2dim sparse  ccolor  image; 2 for 2dim color    %
%                  image sparse under  'db1'. (default: 0)               %
% OUTPUTS:                                                               %
%       X ---- nomalized sample matrix                                   %
%      Xt ---- transpose of X                                            %
%       y ---- noisy data                                                %
%      ye ---- exact data                                                %
%      xe ---- true signal                                               %
%      K  ---- number of nonzero elements in the signal                  %
%    supp ---- the support of xe                                         %
%   suppg ---- support of xe in group level                              %
%   gidx  ---- group index formed as                                     %
%              [ones(d_1,1);2*ones(d_2,1);....;Ks*ones(d_Ks,1)]          %
%               with d_i the length of g_i,i =1,...Ks                    %                      
%invXgsqrt ---- inverse of square root of  X'_{g_i}*X_{g_i},i =1,...Ks   %
%    sinXg ---- singular value of X_{g_i}                                %
%   out   ---- a structure                                               % 
% out.W   ---- the transpose of Wavelet transform                        %
% out.I   ---- the original imgae                                        %
%out.Ibar ---- the mean of Image                                         %
%------------------------------------------------------------------------%
% (c) by Bangti Jin (bangti.jin@gmail.com)                               %
%    and Yuling Jiao (yulingjiaomath@whu.edu.cn)                         %
% Created on 1 June, 2015                                                %
%  modified on Sept. 4, 2015                                             %
%========================================================================%

disp('Generating data ...')
if ~exist('opts','var')
    cor    = 0;
    sigma  = .1;
    ratio  = 3;
    seednum= 0;
    isnorm = 1;
    matrixtype = 'gauss';
    gsize = [];
    twodim = [];
else
    if isfield(opts,'cor')
        cor = opts.cor;
    else
        cor = 0;
    end
    if isfield(opts,'sigma')
        sigma = opts.sigma;
    else
        sigma = .1; 
    end
    if isfield(opts,'ratio')
        ratio = opts.ratio;
    else
        ratio = 2;
    end
    if isfield(opts,'seednum')
        seednum = opts.seednum;
    else
        seednum = 0; 
    end
    if isfield(opts,'matrixtype')
        matrixtype = opts.matrixtype;
    else
        matrixtype = 'gauss';
    end
    if isfield(opts,'isnorm')
        isnorm = opts.isnorm;
    else
        isnorm = 1;
    end
    if isfield(opts,'gsize')
        gsize = opts.gsize;
    else
        gsize = [];
    end
    if isfield(opts,'twodim')
        twodim = opts.twodim;
    else
        twodim = 0;
    end
end
rand('seed',seednum);   % fix seed
randn('seed', seednum); % fix seed
out = [];
% generate signal
if twodim == 0
    xe = zeros(p,1);         % true signal
    if isempty(gsize) 
        avgsize = floor(p/Ks);   % average group size make 
        gidx = [];               % index for groups
        for k = 1:Ks   
            gidx = [gidx; k*ones(avgsize,1)];   
        end
        gidx = [gidx;Ks*ones(p - avgsize*Ks,1)];  % in case p/Ks is not an integer
    else
        if sum(gsize)~=p
            disp('error, the sum of goup size must equal to p')
        else
            gidx = [];             % index for groups
            for k = 1:Ks
                gidx = [gidx;k*ones(gsize(k),1)];   
            end
        end
    end
    q  = randperm(Ks);       % random permutation of Ks, for groups
    suppg = sort((q(1:Kg)))';   % group support 
    idx = ismember(gidx,suppg);
    supp = find(idx);
    K = length(supp);
    if ratio ~= 0
        vx = ratio*rand(K,1);
        vx = vx-min(vx);
        vx = vx/max(vx)*ratio;
        xe(supp) = 10.^vx.*sign(randn(K,1));
    else
        for k = 1:length(suppg)
            id = find(gidx == suppg(k));
            xe(id) = k*sign(randn(length(id),1));
        end
    end
elseif twodim == 1
    load tdim
    [sr sg sb] = size(tdim);
    ps = sr*sg;
    p = sb*ps
    n = floor(p/6)
    xrgb = tdim(:);
    pid = kron((1:ps)',ones(3,1)) + kron(ones(ps,1),[0;ps;2*ps]);
    xe = 1*xrgb(pid);
    Ks = ps
    gindex = [];
    avgsize = sb;   % average group size make 
    gidx = [];      % index for groups
    suppg = [];
    for k = 1:Ks   
        gidx = [gidx; k*ones(avgsize,1)]; 
        if norm(xe((k-1)*avgsize+1: k*avgsize))~= 0
            suppg = [suppg;k];
        end
    end
    Kg = length(suppg)
    K = length(find(xe));
% 20210530-add
elseif twodim == 3
    load I00
    [sr sg sb] = size(I00);
    ps = sr*sg;
    p = sb*ps
    n = floor(p/6)
    xrgb = I00(:);
    pid = kron((1:ps)',ones(3,1)) + kron(ones(ps,1),[0;ps;2*ps]);
    xe = 1*xrgb(pid);
    Ks = ps
    gindex = [];
    avgsize = sb;   % average group size make 
    gidx = [];      % index for groups
    suppg = [];
    for k = 1:Ks   
        gidx = [gidx; k*ones(avgsize,1)]; 
        if norm(xe((k-1)*avgsize+1: k*avgsize))~= 0
            suppg = [suppg;k];
        end
    end
    Kg = length(suppg)
    K = length(find(xe));
%20210530 above end
elseif twodim == 2
    ims = 64;
    nsam = 25;
    Img = getcolor(ims); % color phatom of size ims*ims
%     [Img,cmap] = imread('colorim.png');
%     Img = double(Img(1:3:200,1:3:200,:));
%     id = [2:33,35:66];
%     Img = Img(id,id,:);
    [sr,sg,sb] = size(Img);
    Imgr = Img(:,:,1); 
    Imgg = Img(:,:,2);
    Imgb = Img(:,:,3); 
    Imgbarr = mean(Imgr(:));
    Imgbarg = mean(Imgg(:));
    Imgbarb = mean(Imgb(:));
    Imgcntrr = Imgr -Imgbarr;
    Imgcntrg = Imgg -Imgbarg;
    Imgcntrb = Imgb -Imgbarb;
%  Sampling operator
   [M,Mh,mh,mhi] = LineMask(nsam,sg);
   OMEGA = mhi;
   Phi = @(z) A_fhp(z,OMEGA);      % z is same size of original image, out put is a vector.
   Phit = @(z) At_fhp(z,OMEGA,sg); % z is a vector, out put is same size of original image.
% taking measurements
   ye1 = Phi(Imgcntrr);
   ye2 = Phi(Imgcntrg);
   ye3 = Phi(Imgcntrb);
   ye = [ye1(:);ye2(:);ye3(:)];
   n = length(ye(:))
   wav = 'db1';                 % type of wavelet 
   dW_L = 6;
   [lo,hi,rlo,rhi] = wfilters(wav);
   O = @(z) HDWIdW(Phi,Phit,z,lo,hi,rlo,rhi,1,1,dW_L,0);
   Ot = @(z) HDWIdW(Phi,Phit,z,lo,hi,rlo,rhi,1,1,dW_L,1);
   W = @(z) WaveDecRec(z,dW_L,lo,hi,rlo,rhi,1,1,0);  % Rec
   Wt = @(z) WaveDecRec(z,dW_L,lo,hi,rlo,rhi,1,1,1); % Dec
   xe1 =  Wt(Imgcntrr);
   xe2 =  Wt(Imgcntrg);
   xe3 =  Wt(Imgcntrb);
   xe = [xe1(:);xe2(:);xe3(:)];
   ps = sr*sg;
   p = ps*sb
   sX = zeros(n/sb,ps);
   unuse = Ot(zeros(n/sb,1));
   for k = 1:ps
      ek = zeros(ps,1);
      ek(k) = 1;
      tk = O(ek-mean(ek));
      sX(:,k) = tk(:);
   end
   out.Ibar = [Imgbarr,Imgbarg,Imgbarb];
   out.W = W;
   out.I = Img;
    pid = kron((1:ps)',ones(3,1)) + kron(ones(ps,1),[0;ps;2*ps]);
    xe = 1*xe(pid);
    X = kron(eye(3,3),sX);
    X = X(:,pid);
    Ks = ps
    gindex = [];
    avgsize = sb;   % average group size make 
    gidx = [];      % index for groups
    suppg = [];
    for k = 1:Ks   
        gidx = [gidx; k*ones(avgsize,1)]; 
        if norm(xe((k-1)*avgsize+1: k*avgsize)) > sqrt(3)*10^(-5); % make a threshold
            suppg = [suppg;k];
        end
    end
    Kg = length(suppg)
    K = length(find(xe));
else
    disp('undifined settings');
end
switch matrixtype
    case 'gauss'
        X = randn(n,p);
        [X,invXgsqrt,sinXg] = normalize(X,cor,gidx,isnorm);
        Xt = X';
        ye  = X*xe;
    case 'bernoulli'
        X = sign(randn(n,p));
        [X,invXgsqrt,sinXg] = normalize(X,cor,gidx,isnorm);
        Xt = X';
        ye  = X*xe;
    case 'partdct'
        if twodim == 2
             [X,invXgsqrt,sinXg] = normalize(X,0,gidx,isnorm);
              Xt = X';
        end
    otherwise
        disp('Undefined matrix type')
end
y   = ye + sigma*randn(n,1);
supp = find(abs(xe)>0);
if twodim == 2
          supp = find(abs(xe)>10^(-5));
end
disp('Data generation is done!')
end

function [sX,invXgsqrt,sinXg] = normalize(X,cor,gidx,isnorm)
%------------------------------------------------------------------------%
% purpose: add correlation within group, normalize the sensing matrix X  %
% (columnwise), and compute square-root matrices and its eigenvalue for  %
%  each group                                                            %
% Inputs:                                                                %
%    X     --- un-normalized matrix                                      %
%  cor     --- correlation within the group                              %
%  gidx    --- index for the group                                       %
%  isnorm  --- 1, if normalized                                          %
% Outputs:                                                               %
%     sX     --- normalized matrix                                       %
%  invXgsqrt --- inverse of square root of the group                     %
%   sinXg --- singular value of each group         
%------------------------------------------------------------------------%
p  = size(X,2);
gs = max(gidx); 
sX = X;
invXgsqrt = cell(gs,1);
sinXg = cell(gs,1);
for k = 1:gs
    % corr. within each group
    ind   = find(gidx == k);
    sXsub = sX(:,ind);
    for j = 2:length(ind)-1;
        sXsub(:,j) = sXsub(:,j) + cor *sXsub(:,j+1)+ cor*sXsub(:,j-1);
    end
    sX(:,ind) = sXsub;
end
if isnorm == 1  % normalization
    for k =1:p
        sX(:,k) = sX(:,k)/norm(sX(:,k));
    end
end
for k = 1:gs
        ind   = find(gidx == k);
        Gsub = sX(:,ind)'*sX(:,ind) + 0*1e-8*eye(length(ind ));
        [V,D]= eig(Gsub);
        invXgsqrt{k} = V*(diag(1./sqrt(abs(diag(D)))))*V';
        sinXg{k} = sqrt(abs(diag(D)));
        %sX(:,ind) = sX(:,ind)*invXgsqrt{k};
end
end

%% subfunction below is used for 2d color phantom 
function cI = getcolor(imagesize)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%��This Program get a color phantom image of size imagesize*imagesize     %          
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------------------------------------------------------------------%
% (c) by Bangti Jin (bangti.jin@gmail.com)                               %
%    and Yuling Jiao (yulingjiaomath@whu.edu.cn)                         %
% Created on 1 June, 2016                                                %
%========================================================================%
imt = phantom(imagesize)*255; % the value of  phantom in  [0,1];
load('colorim.mat');
ims = colorim;
imt(:,:,2) = imt(:,:,1);
imt(:,:,3) = imt(:,:,1);
% Converting to ycbcr color space
nspace1 = rgb2ycbcr(ims);
nspace2 = rgb2ycbcr(imt);
ms = double(nspace1(:,:,1));
mt = double(nspace2(:,:,1));
m1 = max(max(ms));
m2 = min(min(ms));
m3 = max(max(mt));
m4 = min(min(mt));
d1 = m1-m2;
d2 = m3-m4;
% Normalization
dx1 = ms;
dx2 = mt;
dx1 =(dx1*255)/(255-d1);
dx2 = (dx2*255)/(255-d2);
[mx,my,mz] = size(dx2);
% Luminance Comparison
for i = 1:mx
    for j = 1:my
        iy=dx2(i,j);
        tmp=abs(dx1-iy);
        ck=min(min(tmp));
        [r,c] = find(tmp==ck);
        ck=isempty(r);
        if (ck~=1)
            nimage(i,j,2)=nspace1(r(1),c(1),2);
            nimage(i,j,3)=nspace1(r(1),c(1),3);
            nimage(i,j,1)=nspace2(i,j,1);
        end
    end
end
cI = double(ycbcr2rgb(nimage))/255;
end


function [M,Mh,mi,mhi] = LineMask(L,N)
% Returns the indicator of the domain in 2D fourier space for the 
% specified line geometry.
% Usage :  [M,Mh,mi,mhi] = LineMask(L,N)
%
% Written by : Justin Romberg
% Created : 1/26/2004
% Revised : 12/2/2004
thc = linspace(0, pi-pi/L, L);
%thc = linspace(pi/(2*L), pi-pi/(2*L), L);
M = zeros(N);
% full mask
for ll = 1:L

	if ((thc(ll) <= pi/4) || (thc(ll) > 3*pi/4))
		yr = round(tan(thc(ll))*(-N/2+1:N/2-1))+N/2+1;
    	for nn = 1:N-1
      	M(yr(nn),nn+1) = 1;
      end
  else 
		xc = round(cot(thc(ll))*(-N/2+1:N/2-1))+N/2+1;
		for nn = 1:N-1
			M(nn+1,xc(nn)) = 1;
		end
	end

end
% upper half plane mask (not including origin)
Mh = M;
Mh(N/2+2:N,:) = 0;
Mh(N/2+1,N/2+1:N) = 0;
M = ifftshift(M);
mi = find(M);
Mh = ifftshift(Mh);
mhi = find(Mh);
end

function y = A_fhp(x, OMEGA)
% Takes measurements in the upper half-plane of the 2D Fourier transform.
% x - N vector
% y - K vector = [mean; real part(OMEGA); imag part(OMEGA)]
% OMEGA - K/2-1 vector denoting which Fourier coefficients to use
%         (the real and imag parts of each freq are kept).
% Written by: Justin Romberg, Caltech and Modified by Yuling Jiao
[s1,s2] = size(x);
n = round(sqrt(s1*s2));
yc = 1/n*fft2(x);
y = [yc(1,1); sqrt(2)*real(yc(OMEGA)); sqrt(2)*imag(yc(OMEGA))];
end

function x = At_fhp(y, OMEGA, n)
% Adjoint of At_fhp (2D Fourier half plane measurements).
% y - K vector = [mean; real part(OMEGA); imag part(OMEGA)]
% OMEGA - K/2-1 vector denoting which Fourier coefficients to use
%         (the real and imag parts of each freq are kept).
% n - Image is nxn pixels
% x - N vector
% Written by: Justin Romberg, Caltech and modified by Yuling Jiao

K = length(y);
fx = zeros(n,n);
fx(1,1) = y(1);
fx(OMEGA) = sqrt(2)*(y(2:(K+1)/2) + 1i*y((K+3)/2:K));
x = real(n*ifft2(fx));
end




function [Y,strc] = WaveDecRec(X,level,lo,hi,rlo,rhi,emd,ds,isdec)
persistent s;
if isdec == 1
    % Phi' * X
   [Y,s] = mwavedec2(X,level,lo,hi,emd,ds);
    strc = s;
    Y = Y';
else
    Y  = mwaverec2(X(:),s,rlo,rhi,emd,0);
    strc = s;
end
end

function Y = HDWIdW(A,At,X,lo,hi,rlo,rhi,emd,ds,L,isdec)
% X: sparse vector which is taken from Wavelet transform of an image 
% A: random projection matrix M x N
% rlo,rhi: scaling filter
% L: level of decomposition
% m, n: size of image
% Return Y: vector M x 1
% Written by Kun Qiu, ISU, April 2009 and modified by Yuling Jiao
persistent s
if isdec == 1 % Ht
     % converting measurements into samples
    if ~isa(At, 'function_handle')
        Y=At*X;
    else
         Y=At(X);
    end
    % converting samples into wavelet coefficients (sparse representation)
    [Y,s]= mwavedec2(Y,L,lo,hi,emd,ds);
    Y = Y';
else 
    Y  = mwaverec2(X(:),s,rlo,rhi,emd,0);
    if ~isa(A, 'function_handle')
       Y = A*Y;
    else
       Y = A(Y);
    end
end
end
