function [x, Acidx, Ac, nIter] = groupomp(X,Xt,y,opts)
%------------------------------------------------------------------------%
% (c) by Bangti Jin (bangti.jin@gmail.com)                               %
%    and Yuling Jiao (yulingjiaomath@whu.edu.cn)                         %
% Created on 1 June, 2015                                                %
%  modified on Sept. 4, 2015                                             %
%========================================================================%
% Input:                                                                 %
%       X  ---  sampling matrix                                          %
%       Xt ---  transpose of X                                           %
%       y  ---  data vector                                              %
%     opts ---  structure containing                                     %
%        gidx  --- group index formed as                                 %
%             [ones(d_1,1);2*ones(d_2,1);....;Ks*ones(d_Ks,1)]           %
%              with d_i the length of g_i,i =1,...Ks                     %                      
%      cgtol   ---  tolerence of CG    (default 1e-5)                    %
%      MaxIt   ---  maximum number of iterations     (default 100)       %
%         del  --- niose level  (defualt 0)                              %
%       alpha  --- stable parameter  (default 0)                         %
% Output:                                                                %
%     x   ---  reconstructed signal                                      %
%  Acidx  ---  acive group index                                         %
%     Ac  ---  acive set  of x                                           %
%   nIter --- # of iteration                                             %
% ========================================================================
disp(' Group OMP for group l0 model is running ...')
implicit = isa(X,'function_handle');
if nargin < 4
    disp('error, not enough inputs');
end
if implicit == 1
    p  = opts.p;
    d = Xt(y);   % initial with 0
    Xty = d;
else
    p   = size(X,2);
    d = X'*y;  % initial with 0
    Xty = d;
end
J = opts.MaxIt;
gidx  = opts.gidx;
x      = zeros(p,1);
normd = normdgroup(d,gidx);
Acidx  = [];
Ac = [];
idx  = find(normd == max(normd));
Acidx = [Acidx;idx];
tid = find(gidx == idx);
Ac = [Ac;tid];
nIter = 0;
ox = x;
res = norm(y);
while res > opts.del && nIter <=J
    nIter = nIter  + 1;
    x = zeros(p,1);
    XtyAc = Xty(Ac);
    if implicit == 0
        Xac = X(:,Ac);
        G = Xac'*Xac +  opts.alpha*eye(length(Ac));
        txac = G \ XtyAc;
    else 
        option.Lt = Xt;
        option.subset = Ac;
        option.p = pq;
        itcg = floor(p/length(Ac))+1; % for real1d
        [txac,~,~] = Subcg(X, XtyAc, opts.cgtol, itcg, ox,[], option);
    end
    x(Ac) = txac;
    if implicit == 0
        r = (y-Xac*txac);
        d = X'*r;
    else
         r = y-X(x);
         d = Xt(r);
    end
    res = norm(r);
    ox = x;
    normd = normdgroup(d,gidx);
    idx  = find(normd == max(normd));
    Acidx = [Acidx;idx];
    tid = find(gidx == idx);
    Ac = [Ac;tid];
end
if res <= opts.del
    disp('DP is satisfied')
end
end

function normgz = normdgroup(d,gidx)
normgz = zeros(max(gidx),1);
for k = 1:max(gidx)
    idxk = gidx == k;
    normgz(k)  = norm(d(idxk));
end
end


function [x, res, iter] = Subcg(L, b, tol, maxiter, initial,verbose, option)
%------------------------------------------------------------------------%
% Solve a symmetric positive definite system Lx = b via CG               %
% Input:                                                                 %
%            L - Either an NxN matrix, or a function handle              %
%            b - N vector                                                %
%          tol - Desired precision.  Algorithm terminates                %
%                when norm(Ax-b) <= tol                                  %
%      maxiter - Maximum number of iterations (defaut length(b))         %
%      initial - Initial value (defaut 0)                                %
%      verbose - If 0, do not print out progress messages                %
%       option - a stucture for subset cg                                %
%             .subset    -  index of conlums of A used                   %
%             .Lt        - transposed of L                               %
%             .p         - number of whole conlums                       %
% Output:                                                                %
%            x -  soultion                                               %
%          res -  residual                                               %
%         iter -  number of iterations                                   %
% Copyright (c)  Yuling Jiao(yulingjiaomath@whu.edu.cn)                  %
% Created on 17 October, 2013                                            %
%------------------------------------------------------------------------%

if ~exist('L','var')|| ~exist('b','var')
    disp('error, not enough inputment');
end
implicit = isa(L,'function_handle');
if ~exist('verbose','var')
    verbose = 0;
end
if nargin < 5
    initial = zeros(size(b));
end
if nargin < 4
    maxiter = length(b);
end
if nargin < 3
    tol = 1e-5;
end
if ~exist('option','var')||isempty(option)
    Aop = L;
    x = initial;
else
    %disp('Subset CG')
    if (implicit)
        subset= option.subset;
        p  = option.p;
        Lt = option.Lt;
        Ssubt = @(z) upsam(z,subset,p);
        Ssub  = @(z) z(subset,:);
        Aop   = @(z) Ssub(Lt(L(Ssubt(z))));
        x     = Ssub(initial);
    else
        subset = option.subset;
        Lt     = option.Lt;
        Ssub   = @(z) z(subset,:);
        Aop    = @(z) Lt*(L*(z));
        x      = Ssub(initial);
        implicit = 1;
    end
end

if (implicit)
    r = b - Aop(x);
else
    r = b - Aop*x;
end
d = r;
delta = r'*r;
iter = 0;
while ((iter < maxiter) && (delta > tol^2))
    if (implicit), q = Aop(d);  else  q = Aop*d;  end
    Alpha = delta/(d'*q);
    x = x + Alpha*d;
    r = r - Alpha*q;
    deltaold = delta;
    delta = r'*r;
    beta = delta/deltaold;
    d = r + beta*d;
    iter = iter + 1;
end
res = sqrt(delta);
if (verbose)
    disp(sprintf('cg: Iterations = %d, best residual = %14.8e', numiter, bestres));
end
end
%% subfunctions
function upz = upsam(z,id,nn)
upz = zeros(nn,1);
upz(id) = z;
end