function [x,lam,ithist,A] = grouppdas(X,Xt,y,opts)
%-----------------------------------------------------------------------%
% minimizing  1/2||X*x-y||^2 + lambda ||x||_l0(l2)                      %
% by group primal dual active set algorithm, with automatic parameter   %
% choice (by DP or BIC)                                                 %
% INPUTS:                                                               %
%     X  ---  sampling matrix (normalized columns)                      %
%     Xt ---  transpose of sampling matrix                              %
%     y  ---  data vector                                               %
%   opts ---  structure containing                                      %
%         N   --- length of path (defaut: 100)                          %
%       Lmax  --- max. in Lam (default: 1)                              %
%       Lmin  --- minimun in Lam (defaut: 1e-8)                         %
%        del  --- noise level                                           %
%       gidx  ---- group index formed as                                %
%             [ones(d_1,1);2*ones(d_2,1);....;Ks*ones(d_Ks,1)]          %
%              with d_i the length of g_i,i =1,...Ks                    %
%        invXgsqrt ---- inverse of square root of  X'_{g_i}*X_{g_i}     %
%     cgtol   ---  tolerence of CG    (default 1e-5                     %
%        mu   --- stop if ||x_{lambda_{k}}||> opts.mu*n (defaut: 0.5)   %
%        x0   --- initial value for PDASC (defaut: 0)                   %
%     MaxIt   --- maximum number of iterations in PDAS  (defaut: 5)     %
%      scale  --- orthogonalizing option    (defaut 1)                  %
%      alpha  --- stable parameter (defualt 1e-8)                       %
% OUTPUTS:                                                              %
%     x   ---- reconstructed signal                                     %
%    lam  ---- regu. parameter (by DP or BIC)                           %
%  ithist ---- structure on iteration history, containing               %
%          .Lam --- reg. para. algong path                              %
%          .x   --- solution path                                       %
%          .as  --- size of active set on the path |A_s|                %
%          .diffup --- |A_{s+1}\A_s|                                    %
%          .diffdown -- |A_s\A_{s+1}|                                   %
%          .it  --- # of iteration on the path                          %
%          .res --- residual on the path                                %
%          .bic --- Bayesian information criterion                      %
%       A ---- group support                                            %
%-----------------------------------------------------------------------%
% (c) by       Bangti Jin (bangti.jin@gmail.com)                        %
%����������and��Yuling Jiao (yulingjiaomath@whu.edu.cn)           ����   %
% Created on 1 June, 2015                                               %
%  modified on Sept. 4, 2015                                            %
%=======================================================================%

implicit = isa(X,'function_handle');
if nargin < 4
    disp('error, not enough inputs!');
end
if implicit == 1
    p   = opts.p;
    Xt  = opts.Xt;
    Xty = Xt(y);
else
    p   = size(X,2);
    Xty = X'*y;
end
n     = length(y);
if ~exist('opts','var')
    opts.N     = 100;         % # of parameters
    opts.Lmax  = 1;           % largest Lambda
    opts.Lmin  = 1e-8;        % smallest Lambda
    opts.MaxIt = 5;           % maximum number of inner iters
    opts.mu    = 0.5;         % sparsity threshold
    opts.del   = 0;           % noise level, (unknown exact data)
    opts.normpd= [];          % normalized primal-dual sum
    opts.scale = 1;           % 1 for orthogonal.,  0 for naive
    opts.alpha = 1e-8;        % local ridge parameter, stabilization
end
opts.Xty  = Xty;
disp(' Group PDAS for group l0 is running ...')
% construct the continuation path
Lam  = exp(linspace(log(opts.Lmax),log(opts.Lmin),opts.N))';
Lam  = Lam(2:end);
cnst = norm(y)^2/2;
Lam  = Lam*cnst;
ithist.Lam = Lam;
A = [];

%% main loop for continuation, choice of lambda, output solution
ithist.x   = [];
ithist.as  = [];
ithist.diffup = [];
ithist.diffdown = [];
ithist.it  = [];
ithist.res = [];
ithist.bic = [];
opts.normpd= [];
x0 = zeros(p,1);
Aold = [];
for k = 1:length(Lam)
    opts.lam = Lam(k);
    [x,s,A,nIt,normpd] = pdasg(X,Xt,y,opts,x0);
    x0 = x;
    opts.normpd = normpd;    % continuation
    if implicit == 0
        res = norm(X*x-y);
    else
        res = norm(X(x)-y);
    end
    ithist.x(:,k)= x;
    ithist.as = [ithist.as;s];
    ithist.diffup = [ithist.diffup;length(setdiff(A,Aold))];
    ithist.diffdown = [ithist.diffdown;length(setdiff(Aold,A))];
    Aold = A;
    ithist.it = [ithist.it;nIt];
    ithist.res= [ithist.res; res];
    ithist.bic= [ithist.bic; 0.5*res^2 + log(p)*s/n];
    % discrepancy principle: if res is known (nonzero)
    if res <= opts.del
        disp('DP is satisfied!')
        lam = Lam(k);
        x   = ithist.x(:,k);
        break;
    end
    if s > opts.mu*max(opts.gidx)
        display('Too many nonzero groups ....')
        break
    end
end
% default choice: Bayesian information criterion
if res > opts.del
    disp('DP does not hold and BIC is used')
    ii = find(ithist.bic == min(ithist.bic));
    ii = ii(end);
    x  = ithist.x(:,ii);
    lam= Lam(ii);
end
end

%% sub functions
function [x,s,A,nIt,normpd] = pdasg(X,Xt,y,opts,x0)
%-------------------------------------------------------------------------%
% solve                                                                   %
%             1/2||X*x-y||^2 + lambda ||x||_{l0(l2)}                      %
% by group primal-dual active set method for given lambda                 %
% INPUTS:                                                                 %
%     X   ---  matrix, normalized                                         %
%     Xt  ---  transpose of sampling matrix                               %
%     y   ---  data vector                                                %
%    opts --- structure contains                                          %
%          lam  ---  regualrization paramter for sparsity                 %
%           mu  ---  stopping parameter                                   %
%        MaxIt  ---  maximum number of iterations (default: 5)            %
%           x0  ---  initial guess (default: 0)                           %
%           pd  ---  sum of primal and dual variable                      %
%         gidx  --- group index formed as                                 %
%             [ones(d_1,1);2*ones(d_2,1);....;Ks*ones(d_Ks,1)]            %
%              with d_i the length of g_i,i =1,...Ks                      %
%     invXgsqrt ---  inverse of square root of  X'_{g_i}*X_{g_i}          %
%       cgtol   ---  tolerence of CG    (default 1e-5                     %
%       scale   ---  1 for weighted (default 1)                           %
% OUTPUTS:                                                                %
%      x  ---  solution                                                   %
%      s  ---  size of active set  of group level                         %
%      A  ---  support of group level                                     %
%     nIt ---  # of iter for the PDAS stop                                %
%  normpd ---  sum of weithed priamal and dual                            %
%=========================================================================%

lam = opts.lam;
Xty = opts.Xty;
T = sqrt(2*lam);
gidx  = opts.gidx;
invXgsqrt = opts.invXgsqrt;
scale = opts.scale;
MaxIt = opts.MaxIt;
implicit = isa(X,'function_handle');
if implicit == 0
    % explicit operator, direct solver for least-squares problem
    [n,p] = size(X);
    % initializing ...
    if ~exist('opts.normpd','var') || isempty(opts.normpd)
        d0     = Xty - Xt*(X*x0);
        normpd = normgroup(x0,d0,gidx,invXgsqrt,scale);
    else
        normpd = opts.normpd;
    end
    s  = 0;
    A  = find(abs(normpd)>T);
    pt = abs(normpd)>T;
    for nIt = 1:MaxIt
        s = length(A);
        Ac = [];
        for k = 1:s
            tid = find(gidx == A(k));
            Ac = [Ac;tid];
        end
        rhs  = Xty(Ac);
        XA   = X(:,Ac);
        G    = XA'*XA;
        x    = zeros(p,1);
        x(Ac)= (G + opts.alpha*eye(size(G)))\rhs;
        if isempty(Ac)
            d = Xt*y;
        else
            d = Xt*(y - XA*x(Ac));
        end
        normpd = normgroup(x,d,gidx,invXgsqrt,scale);
        A    = find(abs(normpd)>T);
        tp   = pt;
        pt   = abs(normpd)>T;
        if length(A) > opts.mu*n;
            % too many nonzero groups
            break;
        end;
        if (pt==tp)
            % active set coincides
            break;
        end;
    end
else
    % implicit operator: CG method for least-squares problem
    n = opts.n;
    p = opts.p;
    % initializing ...
    if ~exist('opts.normpd','var')
        d0  = Xty - Xt(X(x0));
        normpd = normgroup(x0,d0,gidx,invXgsqrt,scale);
    else
        normpd = opts.normpd;
    end
    ox = x0;                  % initial guess for CG iters
    A  = find(abs(normpd)>T); % group active set
    pt = abs(normpd)>T;       % active set - for stopping criterion
    for nIt = 1:opts.MaxIt
        s = length(A);        % size of active set
        Ac= [];               % active set
        for k = 1:s
            tid = find(gidx == A(k));
            Ac = [Ac;tid];
        end
        rhs = Xty(Ac);
        x = zeros(p,1);
        option.Lt = Xt;
        option.subset = Ac;
        option.p = p;
        x(Ac) = Subcg(X, rhs, opts.cgtol, floor(p/s), ox,[], option);
        ox = x;
        d = Xt(y - X(x));
        normpd = normgroup(x,d,gidx,invXgsqrt,scale);
        A = find(abs(pd)>T);
        tp = pt;
        pt = abs(pd)>T;
        if length(A) > opts.mu*n; % too many nonzero groups
            break;
        end;
        if (pt==tp)    % active set coincides
            break;
        end;
    end
end
end

function normgz = normgroup(x,d,gidx,invXgsqrt,scale)
normgz = zeros(max(gidx),1);
for k = 1:max(gidx)
    idxk = find(gidx == k);
    Gidxk = invXgsqrt{k};
    if scale == 1
        normgz(k)  = norm(Gidxk\x(idxk)+  Gidxk*d(idxk));
    else
        normgz(k)  = norm(x(idxk)+ d(idxk));
    end
end
end

function [x, res, iter] = Subcg(L, b, tol, maxiter, initial, verbose, option)
%------------------------------------------------------------------------%
% solve a linear system Lx = b, with L symmetric positive definite via CG%
% Input:                                                                 %
%            L - either an NxN matrix, or a function handle              %
%            b - N vector                                                %
%          tol - precision.  algorithm terminates if |Ax-b| <= tol       %
%      maxiter - max # of iter (defaut: length(b))                       %
%      initial - initial value (defaut 0)                                %
%      verbose - If 0, do not print out progress messages                %
%       option - a stucture for subset cg                                %
%             .subset -  index of conlums of A used                      %
%             .Lt     - transposed of L                                  %
%             .p      - number of whole conlums                          %
% Output:                                                                %
%            x -  soultion                                               %
%          res -  residual                                               %
%         iter -  number of iterations                                   %
%------------------------------------------------------------------------%

if ~exist('L','var')|| ~exist('b','var')
    disp('error, not enough inputment');
end
implicit = isa(L,'function_handle');
if ~exist('verbose','var')
    verbose = 0;
end
if nargin < 5
    initial = zeros(size(b));
end
if nargin < 4
    maxiter = length(b);
end
if nargin < 3
    tol = 1e-5;
end
if ~exist('option','var')||isempty(option)
    Aop = L;
    x = initial;
else
    %disp('Subset CG')
    if (implicit)
        subset= option.subset;
        p  = option.p;
        Lt = option.Lt;
        Ssubt = @(z) upsam(z,subset,p);
        Ssub  = @(z) z(subset,:);
        Aop   = @(z) Ssub(Lt(L(Ssubt(z))));
        x     = Ssub(initial);
    else
        subset = option.subset;
        Lt     = option.Lt;
        Ssub   = @(z) z(subset,:);
        Aop    = @(z) Lt*(L*(z));
        x      = Ssub(initial);
        implicit = 1;
    end
end

if (implicit)
    r = b - Aop(x);
else
    r = b - Aop*x;
end
d = r;
delta = r'*r;
iter = 0;
while ((iter < maxiter) && (delta > tol^2))
    if (implicit)
        q = Aop(d);
    else
        q = Aop*d;
    end
    Alpha = delta/(d'*q);
    x = x + Alpha*d;
    r = r - Alpha*q;
    deltaold = delta;
    delta = r'*r;
    beta = delta/deltaold;
    d = r + beta*d;
    iter = iter + 1;
end
res = sqrt(delta);
if (verbose)
    display(sprintf('cg: Iterations = %d, best residual = %14.8e', numiter, bestres));
end
end
%% subfunctions
function upz = upsam(z,id,nn)
upz = zeros(nn,1);
upz(id) = z;
end