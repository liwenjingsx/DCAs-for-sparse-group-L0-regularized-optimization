function [x,ithist] = groupcd(X,y,rho,opts)
%-----------------------------------------------------------------------%
% coordinate descent algorithm for group lasso, MCP, SCAD penalties     %
% coupled with a path-following on regularization parameter (Dp and Bic % 
% for selecting regularization parameter                                %
%  INPUTS                                                               %
%     X  ---- sensing matrix (group orthogonal)                         %
%     y  ---- noisy data                                                %
%    rho ---- penalty (lasso, mcp, scad)                                %
%   opts ---- structure contains ....                                   %
%       MaxIt --- max. number of iterations                             %
%   gidx  ---- group index formed as                                    %
%              [ones(d_1,1);2*ones(d_2,1);....;Ks*ones(d_Ks,1)]         %
%               with d_i the length of g_i,i =1,...Ks                   %                      
%         tol --- stopping tolerance                                    %
%         del --- noise level for DP                                    %
%          x0 --- initial value (default 0)                             %
% OUTPUTS                                                               %
%       x    --- the solution                                           %
%    ithit   --- structure contains                                     %
%            Lam  -- regularization paramter path                       %
%            x    -- solutions on the path (in colunm)                  %
%            it   -- number of iteration on the path                    %
%            res  -- residual on the path                               %
%            bic  -- bic value on the path                              %
%            Acs  -- active set size on the path                        %
%            lam  -- regularization paramter for x                      %
%          suppxg -- support of x at group level                        %
%========================================================================
% (c) by Bangti Jin (bangti.jin@gmail.com)                              %
%    and Yuling Jiao (yulingjiaomath@whu.edu.cn)                        %
% Created on Sept. 3, 2015                                              %
% ref: P Breheny, J Huang. Stat. Comput. 2015, 25, 173-187              %
%-----------------------------------------------------------------------%

if nargin < 4
    error('Not enough input parameters!');
end
switch rho
    case 'lasso'
       disp(' CD for group Lasso is running ...')
    case 'scad'
        disp(' CD for group SCAD is running ...')
    case 'mcp'
        disp(' CD for group MCP is running ...')
    otherwise
        error('Undefined penalty in coordinate descent !')
end
[n,p]   = size(X);
x0    = zeros(p,1);
Lam  = exp(linspace(log(opts.Lmax),log(opts.Lmin),opts.N))';
Lam  = Lam(2:end);
cnst = norm(X'*y,inf);
Lam  = Lam*cnst;
ithist.Lam = Lam;

%% main loop for pathfolling and choosing lambda and output solution
ithist.x   = [];
ithist.it  = [];
ithist.res = [];
ithist.bic = [];
ithist.Acs = [];
for k = 1:length(Lam)
    opts.lam = Lam(k);
    [x,nIt,suppxg] = gcd(X,y,rho,opts,x0);
    x0 = x;
    res = norm(X*x-y);
    ithist.x(:,k)= x;
    ithist.it = [ithist.it;nIt];
    ithist.res  = [ithist.res; res];
    ithist.suppxg = suppxg;
    s = length(suppxg);
    ithist.Acs = [ithist.Acs; s];
    ithist.bic= [ithist.bic; 0.5*res^2 + log(p)*s/max(opts.gidx)];
    if res <= 1.01*opts.del
        disp('DP is satisfied!')
        ithist.lam = Lam(k);
        ithist.suppxg = suppxg; 
        x   = ithist.x(:,k);
        break;
    end
    if s >= opts.mu*max(opts.gidx)
        display('Too many nonzero groups ....')
        break
    end
end
if res > 1.01*opts.del
    disp('DP does not hold and BIC is used')
    ii = find(ithist.bic == min(ithist.bic));
    ii = ii(end);
    x  = ithist.x(:,ii);
    ithist.lam= Lam(ii);
    ithist.suppxg = suppxg;
end

end

function [x,nIt,suppxg] = gcd(X,y,rho,opts,x0)
gidx  = opts.gidx;
Ks    = max(gidx);
maxIt = opts.MaxIt;
tol   = opts.tol;
x     = x0;
r     = y - X*x;
suppxg = [];
for nIt = 1 : maxIt
    x0 = x;
    suppxg = [];
    for j = 1:Ks
        idx = find(gidx == j);
        Xidx  = X(:,idx);
        z   = Xidx'*r + x(idx);
        z   = threshold(z,rho,opts);
        r   = r - Xidx*(z-x(idx));
        x(idx) = z;
        if norm(z) > 0
           suppxg = [suppxg;j];
        end 
    end
    if norm(x-x0) <= tol*norm(x)
        break
    end
end

end

function z = threshold(x,rho,opts)
%------------------------------------------------------------------------%
% group thresholding operator for lasso, MCP, SCAD                       %
% INPUTS                                                                 %
%     x    --- input vector                                              %
%     rho  --- penalty (lasso, mcp, scad)                                %
%    opts  --- structure containing ...                                  %
%         lam   --- reg. param.                                          %
%         tau   --- concavity parameter                                  %
% OUTPUTS                                                                %
%     z    --- thresholded vector                                        %
%------------------------------------------------------------------------%

if nargin < 3, error('Not enough parameters !'); end
lam = opts.lam;
tau = opts.tau;
t = norm(x);
switch rho
    case 'lasso'
        z = max(t-lam,0);
    case 'scad'
        if t > tau*lam
            z = t;
        elseif t > 2*lam
            z = max(t-tau*lam/(tau-1),0)/(1-1/(tau-1));
        else
            z = max(t-lam,0);
        end
    case 'mcp'
        if t > tau*lam
            z = t;
        else
            z = max(t-lam,0)/(1-1/tau);
        end
    otherwise
        error('Undefined penalty in coordinate descent !')
end
if t == 0
   z = x;
else
    z = z*x/t;
end
end