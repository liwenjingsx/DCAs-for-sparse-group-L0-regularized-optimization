clc, clear, close all
addpath(genpath(fileparts(mfilename('fullpath'))));
%% Generate data;
p = 2000;             % length of solution  
n = 500;              % number of samples
Ks = 500;
dopts.sigma = 0.01;
dopts.cor = 5;   
dopts.ratio = 1;
Kg = 50;
dopts.seednum  = 0;
[X,Xt,y,ye,xe,K,supp,suppg,gidx,invXgsqrt,sinXg] = gendata(n,p,Ks,Kg,dopts);
%% group pdas
opts = setopts(gidx,invXgsqrt,'gpdas');
opts.scale = 1;
opts.del = norm(y-ye);
opts.alpha = 0e-6;
opts.Lmin = 1e-8;
tic, [x,lam,ithist,A] = grouppdas(X,Xt,y,opts); toc
Ap = length(setdiff(suppg,A));
Am = length(setdiff(A,suppg));
rel2err = norm(x - xe)/norm(xe);
display(['|A \ A^*| = ' num2str(Ap) '   |A^* \ A| = ' num2str(Am)])
abslinferr = norm(x- xe,inf);
display(sprintf(' #  ral l_2 error = %g, abs l_inf error = %g',rel2err, abslinferr))
figure(1), plot(1:p,xe,'ko',1:p,x,'r*'), 
h = title('GPDASC, xe  (o) and x   (*)');
set(h,'Interpreter','latex','fontsize',13)

