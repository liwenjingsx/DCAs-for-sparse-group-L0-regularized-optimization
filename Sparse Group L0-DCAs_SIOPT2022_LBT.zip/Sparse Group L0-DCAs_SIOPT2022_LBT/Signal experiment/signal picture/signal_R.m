clc, clear all, close all
maxiter1=5000;
maxiter2=5000;
tol = 1e-15;
%tol=0;
%% Problem generation
index=1;
sigma=0.01;
n = 160*index;
m = 80*index;
k = 16*index;
lambda=1;
deta=10;
        
%I = randperm(n);
%J = I(1:k);
%x = zeros(n,1);
%x(J) = unifrnd(2,10,[k,1]);
%%for k=1:1
%A=randn(m,n);
%A=orth(A')';
%sr=sigma*randn(m,1);
%b = A*x + sr;

%save n16000_x.mat x
%save n16000_A.mat A
%save n16000_sr.mat sr
%save n16000_b.mat b

load n160_x.mat
load n160_A.mat
load n160_sr.mat
load n160_b.mat

%% algorithm parameter
%Lf=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*b,inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*b),inf)]);
%v=0.99*min(lambda/Lf,deta);
%Ls=2*norm(A)^2;
%c=Ls/4;
%alphaB=Ls/4;

%save n16000_Lf.mat Lf
%save n16000_v.mat v
%save n16000_Ls.mat Ls
%save n16000_c.mat c
%save n16000_alphaB.mat alphaB

load n160_Lf.mat
load n160_v.mat
load n160_Ls.mat
load n160_c.mat
load n160_alphaB.mat

rho=2;
k=1;
%% run
tic
%alg1 or alg1fig
%[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB, deta, v, c, rho, maxiter1, tol);
[F,F1,dF1,dFx1,x_new,x_old,iter,a] = alg1fig( n, A, b, lambda, alphaB, deta, v, c, rho, maxiter1, tol);
Time_ag1(1,k)=toc;
Iter_ag1(1,k)=iter;
MSE_ag1(1,k)=norm(x_new-x)^2/n;
dX_ag1(1,k)=norm(x_new-x_old);
dF_ag1(1,k)=abs(F-F1);
Z_ag1(1,k)=sum(abs(x_new) > 0);
a_ag1(1,k)=a;
S_ag1=[mean(Iter_ag1);mean(Time_ag1);mean(MSE_ag1);mean(dX_ag1);mean(dF_ag1);mean(Z_ag1);mean(a_ag1)];
x1=x_new;
%save n16000_x1.mat x1
%save n16000_S_ag1.mat S_ag1
fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', mean(Iter_ag1), mean(Time_ag1), mean(MSE_ag1));
fprintf(' dX1 = %5.2d  dF1 = %5.2d  Z1 = %3d\n a = %3d\n', mean(dX_ag1), mean(dF_ag1), mean(Z_ag1),mean(a_ag1));

figure(1)
scatter(1:n,x(:,1),'o','LineWidth',5)
hold on
scatter(1:n,x_new(:,1),'x','lineWidth',2)
hold on
xlabel('index')
ylabel('value')


%alg2 or alg2fig
tic
%[F2,F21,x_new2,x_old2,iter2] = alg2( n, A, b, Ls, lambda, deta, v, maxiter2, tol);
[F2,F21,dF2,dFx2,x_new2,x_old2,iter2]=alg2fig( n, A, b, Ls, lambda, deta, v, maxiter2, tol);
Time_ag2(1,k)=toc;
Iter_ag2(1,k)=iter2;
MSE_ag2(1,k)=norm(x_new2-x)^2/n;
dX_ag2(1,k)=norm(x_new2-x_old2);
dF_ag2(1,k)=abs(F2-F21);
Z_ag2(1,k)=sum(abs(x_new2) > 0);
S_ag2=[mean(Iter_ag2);mean(Time_ag2);mean(MSE_ag2);mean(dX_ag2);mean(dF_ag2);mean(Z_ag2)];
x2=x_new2;
%save n16000_x2.mat x2
%save n16000_S_ag2.mat S_ag2
fprintf(' iter2 = %5.2d  time2 = %5.2f  MSE2 = %3.2d\n', mean(Iter_ag2), mean(Time_ag2), mean(MSE_ag2));
fprintf(' dX2 = %5.2d  dF2 = %5.2d  Z2 = %3d\n', mean(dX_ag2), mean(dF_ag2), mean(Z_ag2));
figure(2)
scatter(1:n,x(:,1),'c','LineWidth',5)
hold on
scatter(1:n,x_new2(:,1),'x','lineWidth',2)
hold on
xlabel('index')
ylabel('value')

FF1=[];FF2=[];FF3=[];
for j=1:iter2+1
    FF1=[FF1;1/j^1];FF2=[FF2;1/j^2];FF3=[FF3;1/j^3];
end
iter2=81
dF11=[];
for k=1:iter
dF11(2*k-1,:)=dF1(k,:);
dF11(2*k,:)=dF1(k,:);
end
figure(3)
X1=0:2:iter2;Y1=1:2:iter2+1;Y2=1:iter2+1;
semilogy(X1,dF11(Y1),'LineWidth',1.0)
hold on
semilogy(0:iter2,dF2(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF1(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF2(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF3(Y2),'LineWidth',1.0)
hold on
xlabel('$k$')

%%axes('position',[0.25,0.55,0.25,0.25]); 
%%semilogy(0:iter2,dF2,'-','linewidth',1); 
%%xlim([25,35]);ylim([0,1e-5]);
%%axes('position',[0.55,0.55,0.25,0.25]); 
%%plot(0:iter2,dF2,'-','linewidth',1); 
%%xlim([35,45]);ylim([0,1e-10]);
%%ylabel('$F(x^{k_2})-F(\bar{x}^2)$')
dFx11=[];
for k=1:iter
dFx11(2*k-1,:)=dFx1(k,:);
dFx11(2*k,:)=dFx1(k,:);
end
figure(4)
semilogy(X1,dFx11(Y1),'LineWidth',1.0)
hold on
semilogy(0:iter2,dFx2(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF1(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF2(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF3(Y2),'LineWidth',1.0)
hold on
xlabel('$k$')


%end