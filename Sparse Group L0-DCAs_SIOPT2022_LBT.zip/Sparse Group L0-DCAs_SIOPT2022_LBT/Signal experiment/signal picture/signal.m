clc, clear all, close all
maxiter1=5000;
maxiter2=5000;
tol = 1e-15;
%tol=0;
% Problem generation
index=1;
sigma=0.01;
% signal length
n = 160*index;
% number of observations to make
m = 80*index;
%number of spikes to put down
k = 16*index; % originally 16*index
lambda=1;
deta=10;
        
%I = randperm(n);
%J = I(1:k);
%x = zeros(n,1);
%x(J) = unifrnd(2,10,[k,1]);
 %x(J) = 5+randn(k,1);
%Time_ag1=[];Iter_ag1=[];MSE_ag1=[];dX_ag1=[];dF_ag1=[];Z_ag1=[];S_ag1=[];a_ag1=[];
%Time_ag2=[];Iter_ag2=[];MSE_ag2=[];dX_ag2=[];dF_ag2=[];Z_ag2=[];S_ag2=[];
for k=1:1
%A=randn(m,n);
%A=orth(A')';
 %for j = 1:n
 %    A(:,j) = A(:,j)/norm(A(:,j));
 %end
%��˹������
%sr=sigma*randn(m,1);
 %��������
 %sr=sigma*raylrnd(1,m,1);
 %����٤������
 %sr=sigma*gamrnd(1,2,[m,1]);
 %����ָ������
 %sr=sigma*exprnd(2,[m,1]);
 %���Ӿ��ȷֲ�����
 %sr=sigma*unifrnd(0,2,[m,1]);
%b = A*x + sr;
 %norm(sr)^2
%save n16000x.mat x
%save n16000A.mat A
%save n16000sr.mat sr
%save n16000b.mat b

load n1600x.mat
load n1600A.mat
load n1600sr.mat
load n1600b.mat

% algorithm parameter
%Lf=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*b,inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*b),inf)]);
 %Lf1=norm(A,inf);%Lf2=norm(A);%Lf=2*norm(A)*norm(sr);
%v=0.99*min(lambda/Lf,deta);
%Ls=eigs(A*A',1);
 %Ls=norm(A)^2;
%c=0.5;
%save Lf.mat Lf
%save Ls.mat Ls
%save c.mat c
%save v.mat v
load Lf.mat
load Ls.mat
Ls=Ls*2;
load c.mat
load v.mat
rho=2;
%alphab1=1e-8;
%alphab2=1e+8;
%alpha00=1;
%re_freq = 200;
%% run
tic
%alg1 or alg1fig
%[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, deta, v, c, rho, maxiter1, tol);
[F,F1,dF1,dFx1,x_new,x_old,iter,a] = alg1fig( n, A, b, lambda, deta, v, c, rho, maxiter1, tol);
Time_ag1(1,k)=toc;
Iter_ag1(1,k)=iter;
MSE_ag1(1,k)=norm(x_new-x)^2/n;
dX_ag1(1,k)=norm(x_new-x_old);
dF_ag1(1,k)=abs(F-F1);
Z_ag1(1,k)=sum(abs(x_new) > 0);
a_ag1(1,k)=a;
S_ag1=[mean(Iter_ag1);mean(Time_ag1);mean(MSE_ag1);mean(dX_ag1);mean(dF_ag1);mean(Z_ag1);mean(a_ag1)];
%x1=x_new;
%save n1600x1.mat x1
%save S_ag1_1n1600.mat S_ag1
fprintf(' iter1 = %5.2d  time1 = %5.2f  MSE1 = %3.2d\n', mean(Iter_ag1), mean(Time_ag1), mean(MSE_ag1));
fprintf(' dX1 = %5.2d  dF1 = %5.2d  Z1 = %3d\n a = %3d\n', mean(dX_ag1), mean(dF_ag1), mean(Z_ag1),mean(a_ag1));

%figure(1)
%scatter(1:n,x(:,1),'o','LineWidth',5)
%hold on
%scatter(1:n,x_new(:,1),'x','lineWidth',2)
%hold on
%xlabel('index')
%ylabel('value')
%FF1=[];FF2=[];FF3=[];
%for j=1:iter+1
%    FF1=[FF1;1/j^1];FF2=[FF2;1/j^2];FF3=[FF3;1/j^3];
%end

%alg2 or alg2fig
tic
%[F2,F21,x_new2,x_old2,iter2] = alg2( n, A, b, Ls, lambda, deta, v, maxiter2, tol);
[F2,F21,dF2,dFx2,x_new2,x_old2,iter2]=alg2fig( n, A, b, Ls, lambda, deta, v, maxiter2, tol);
Time_ag2(1,k)=toc;
Iter_ag2(1,k)=iter2;
MSE_ag2(1,k)=norm(x_new2-x)^2/n;
dX_ag2(1,k)=norm(x_new2-x_old2);
dF_ag2(1,k)=abs(F2-F21);
Z_ag2(1,k)=sum(abs(x_new2) > 0);
S_ag2=[mean(Iter_ag2);mean(Time_ag2);mean(MSE_ag2);mean(dX_ag2);mean(dF_ag2);mean(Z_ag2)];
%x2=x_new2;
%save n1600x2.mat x2
%save S_ag2_1n1600.mat S_ag2
fprintf(' iter2 = %5.2d  time2 = %5.2f  MSE2 = %3.2d\n', mean(Iter_ag2), mean(Time_ag2), mean(MSE_ag2));
fprintf(' dX2 = %5.2d  dF2 = %5.2d  Z2 = %3d\n', mean(dX_ag2), mean(dF_ag2), mean(Z_ag2));
%figure(2)
%scatter(1:n,x(:,1),'c','LineWidth',5)
%hold on
%scatter(1:n,x_new2(:,1),'x','lineWidth',2)
%hold on
%xlabel('index')
%ylabel('value')

FF1=[];FF2=[];FF3=[];
for j=1:iter2+1
    FF1=[FF1;1/j^1];FF2=[FF2;1/j^2];FF3=[FF3;1/j^3];
end
iter2=80
dF11=[];
for k=1:iter
dF11(2*k-1,:)=dF1(k,:);
dF11(2*k,:)=dF1(k,:);
end
figure(3)
X1=0:2:iter2;Y1=1:2:iter2+1;Y2=1:iter2+1;
semilogy(X1,dF11(Y1),'LineWidth',1.0)
hold on
semilogy(0:iter2,dF2(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF1(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF2(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF3(Y2),'LineWidth',1.0)
hold on
xlabel('$k$')
%ylabel('$3$')
%axes('position',[0.25,0.55,0.25,0.25]); 
%semilogy(0:iter2,dF2,'-','linewidth',1); 
%xlim([25,35]);ylim([0,1e-5]);
%axes('position',[0.55,0.55,0.25,0.25]); 
%plot(0:iter2,dF2,'-','linewidth',1); 
%xlim([35,45]);ylim([0,1e-10]);
%ylabel('$F(x^{k_2})-F(\bar{x}^2)$')
dFx11=[];
for k=1:iter
dFx11(2*k-1,:)=dFx1(k,:);
dFx11(2*k,:)=dFx1(k,:);
end
figure(4)
semilogy(X1,dFx11(Y1),'LineWidth',1.0)
hold on
semilogy(0:iter2,dFx2(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF1(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF2(Y2),'LineWidth',1.0)
hold on
semilogy(0:iter2,FF3(Y2),'LineWidth',1.0)
hold on
xlabel('$k$')
%ylabel('$4$')


end