clear all;
maxiter1=5000;
maxiter2=5000;
tol = 1e-15;
%tol=0;
% Problem generation
index=10;
sigma=0.01;
% signal length
n = 160*index;
% number of observations to make
m = 80*index;
%number of spikes to put down
k = 16*index; % originally 16*index
lambda=1;
deta=10;
        
I = randperm(n);
J=I(1:k);
x = zeros(n,1);
x(J)=unifrnd(2,10,[k,1]);
x=[x,x,x,x,x];
Time_ag1=[];Iter_ag1=[];MSE_ag1=[];dX_ag1=[];dF_ag1=[];Z_ag1=[];S_ag1=[];a_ag1=[];
Time_ag1_R=[];Iter_ag1_R=[];MSE_ag1_R=[];dX_ag1_R=[];dF_ag1_R=[];Z_ag1_R=[];S_ag1_R=[];a_ag1_R=[];
for k=1:10
A=randn(m,n);
A=orth(A')';
%for j = 1:n
%    A(:,j) = A(:,j)/norm(A(:,j));
%end
%��˹������
sr(:,1)=sigma*randn(m,1);
%��������
sr(:,2)=sigma*raylrnd(1,m,1);
%����٤������
sr(:,3)=sigma*gamrnd(1,2,[m,1]);
%����ָ������
sr(:,4)=sigma*exprnd(2,[m,1]);
%���Ӿ��ȷֲ�����
sr(:,5)=sigma*unifrnd(0,2,[m,1]);
B = A*x + sr;
%norm(sr)^2


% algorithm parameter
Lf1=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*B(:,1),inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*B(:,1)),inf)]);
Lf2=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*B(:,2),inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*B(:,2)),inf)]);
Lf3=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*B(:,3),inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*B(:,3)),inf)]);
Lf4=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*B(:,4),inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*B(:,4)),inf)]);
Lf5=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*B(:,5),inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*B(:,5)),inf)]);

Ls=2*eigs(A*A',1);
%Ls=norm(A)^2;
c=Ls/4;
alphaB1=Ls/8;
alphaB2=Ls/15;
rho=2;

% run
v=0.99*min(lambda/Lf1,deta);b=B(:,1);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol);
Time_ag1(1,k)=toc;
Iter_ag1(1,k)=iter;
MSE_ag1(1,k)=norm(x_new-x(:,1))^2/n;
dX_ag1(1,k)=norm(x_new-x_old);
dF_ag1(1,k)=abs(F-F1);
Z_ag1(1,k)=sum(abs(x_new) > 0);
a_ag1(1,k)=a;
S_ag1(1,:)=[mean(Iter_ag1(1,:));mean(Time_ag1(1,:));mean(MSE_ag1(1,:));mean(dX_ag1(1,:));mean(dF_ag1(1,:));mean(Z_ag1(1,:));mean(a_ag1(1,:))];

tic
[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol);
Time_ag1_R(1,k)=toc;
Iter_ag1_R(1,k)=iter;
MSE_ag1_R(1,k)=norm(x_new-x(:,1))^2/n;
dX_ag1_R(1,k)=norm(x_new-x_old);
dF_ag1_R(1,k)=abs(F-F1);
Z_ag1_R(1,k)=sum(abs(x_new) > 0);
a_ag1_R(1,k)=a;
S_ag1_R(1,:)=[mean(Iter_ag1_R(1,:));mean(Time_ag1_R(1,:));mean(MSE_ag1_R(1,:));mean(dX_ag1_R(1,:));mean(dF_ag1_R(1,:));mean(Z_ag1_R(1,:));mean(a_ag1_R(1,:))];

v=0.99*min(lambda/Lf2,deta);b=B(:,2);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol);
Time_ag1(2,k)=toc;
Iter_ag1(2,k)=iter;
MSE_ag1(2,k)=norm(x_new-x(:,2))^2/n;
dX_ag1(2,k)=norm(x_new-x_old);
dF_ag1(2,k)=abs(F-F1);
Z_ag1(2,k)=sum(abs(x_new) > 0);
a_ag1(2,k)=a;
S_ag1(2,:)=[mean(Iter_ag1(2,:));mean(Time_ag1(2,:));mean(MSE_ag1(2,:));mean(dX_ag1(2,:));mean(dF_ag1(2,:));mean(Z_ag1(2,:));mean(a_ag1(2,:))];

tic
[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol);
Time_ag1_R(2,k)=toc;
Iter_ag1_R(2,k)=iter;
MSE_ag1_R(2,k)=norm(x_new-x(:,2))^2/n;
dX_ag1_R(2,k)=norm(x_new-x_old);
dF_ag1_R(2,k)=abs(F-F1);
Z_ag1_R(2,k)=sum(abs(x_new) > 0);
a_ag1_R(2,k)=a;
S_ag1_R(2,:)=[mean(Iter_ag1_R(2,:));mean(Time_ag1_R(2,:));mean(MSE_ag1_R(2,:));mean(dX_ag1_R(2,:));mean(dF_ag1_R(2,:));mean(Z_ag1_R(2,:));mean(a_ag1_R(2,:))];

v=0.99*min(lambda/Lf3,deta);b=B(:,3);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol);
Time_ag1(3,k)=toc;
Iter_ag1(3,k)=iter;
MSE_ag1(3,k)=norm(x_new-x(:,3))^2/n;
dX_ag1(3,k)=norm(x_new-x_old);
dF_ag1(3,k)=abs(F-F1);
Z_ag1(3,k)=sum(abs(x_new) > 0);
a_ag1(3,k)=a;
S_ag1(3,:)=[mean(Iter_ag1(3,:));mean(Time_ag1(3,:));mean(MSE_ag1(3,:));mean(dX_ag1(3,:));mean(dF_ag1(3,:));mean(Z_ag1(3,:));mean(a_ag1(3,:))];

tic
[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol);
Time_ag1_R(3,k)=toc;
Iter_ag1_R(3,k)=iter;
MSE_ag1_R(3,k)=norm(x_new-x(:,3))^2/n;
dX_ag1_R(3,k)=norm(x_new-x_old);
dF_ag1_R(3,k)=abs(F-F1);
Z_ag1_R(3,k)=sum(abs(x_new) > 0);
a_ag1_R(3,k)=a;
S_ag1_R(3,:)=[mean(Iter_ag1_R(3,:));mean(Time_ag1_R(3,:));mean(MSE_ag1_R(3,:));mean(dX_ag1_R(3,:));mean(dF_ag1_R(3,:));mean(Z_ag1_R(3,:));mean(a_ag1_R(3,:))];

v=0.99*min(lambda/Lf4,deta);b=B(:,4);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol);
Time_ag1(4,k)=toc;
Iter_ag1(4,k)=iter;
MSE_ag1(4,k)=norm(x_new-x(:,4))^2/n;
dX_ag1(4,k)=norm(x_new-x_old);
dF_ag1(4,k)=abs(F-F1);
Z_ag1(4,k)=sum(abs(x_new) > 0);
a_ag1(4,k)=a;
S_ag1(4,:)=[mean(Iter_ag1(4,:));mean(Time_ag1(4,:));mean(MSE_ag1(4,:));mean(dX_ag1(4,:));mean(dF_ag1(4,:));mean(Z_ag1(4,:));mean(a_ag1(4,:))];

[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol);
Time_ag1_R(4,k)=toc;
Iter_ag1_R(4,k)=iter;
MSE_ag1_R(4,k)=norm(x_new-x(:,4))^2/n;
dX_ag1_R(4,k)=norm(x_new-x_old);
dF_ag1_R(4,k)=abs(F-F1);
Z_ag1_R(4,k)=sum(abs(x_new) > 0);
a_ag1_R(4,k)=a;
S_ag1_R(4,:)=[mean(Iter_ag1_R(4,:));mean(Time_ag1_R(4,:));mean(MSE_ag1_R(4,:));mean(dX_ag1_R(4,:));mean(dF_ag1_R(4,:));mean(Z_ag1_R(4,:));mean(a_ag1_R(4,:))];

v=0.99*min(lambda/Lf5,deta);b=B(:,5);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol);
Time_ag1(5,k)=toc;
Iter_ag1(5,k)=iter;
MSE_ag1(5,k)=norm(x_new-x(:,5))^2/n;
dX_ag1(5,k)=norm(x_new-x_old);
dF_ag1(5,k)=abs(F-F1);
Z_ag1(5,k)=sum(abs(x_new) > 0);
a_ag1(5,k)=a;
S_ag1(5,:)=[mean(Iter_ag1(5,:));mean(Time_ag1(5,:));mean(MSE_ag1(5,:));mean(dX_ag1(5,:));mean(dF_ag1(5,:));mean(Z_ag1(5,:));mean(a_ag1(5,:))];

[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol);
Time_ag1_R(5,k)=toc;
Iter_ag1_R(5,k)=iter;
MSE_ag1_R(5,k)=norm(x_new-x(:,5))^2/n;
dX_ag1_R(5,k)=norm(x_new-x_old);
dF_ag1_R(5,k)=abs(F-F1);
Z_ag1_R(5,k)=sum(abs(x_new) > 0);
a_ag1_R(5,k)=a;
S_ag1_R(5,:)=[mean(Iter_ag1_R(5,:));mean(Time_ag1_R(5,:));mean(MSE_ag1_R(5,:));mean(dX_ag1_R(5,:));mean(dF_ag1_R(5,:));mean(Z_ag1_R(5,:));mean(a_ag1_R(5,:))];
end
%save S_ag1_5non1600sg1e-4.mat S_ag1
%save S_ag1_R_5non1600sg1e-4.mat S_ag1_R