clear all;
maxiter1=5000;
maxiter2=5000;
tol = 1e-15;
%tol=0;
% Problem generation
index=10;
sigma=0.01;
% signal length
n = 160*index;
% number of observations to make
m = 80*index;
%number of spikes to put down
k = 16*index; % originally 16*index
lambda=1;
deta=10;
        
I = randperm(n);
J = I(1:k);
x = zeros(n,1);
x(J) = unifrnd(2,10,[k,1]);
%x(J) = 5+randn(k,1);
Time_ag1=[];Iter_ag1=[];MSE_ag1=[];dX_ag1=[];dF_ag1=[];Z_ag1=[];S_ag1=[];a_ag1=[];
Time_ag1_R=[];Iter_ag1_R=[];MSE_ag1_R=[];dX_ag1_R=[];dF_ag1_R=[];Z_ag1_R=[];S_ag1_R=[];
for k=1:10
A=randn(m,n);
A=orth(A')';
%for j = 1:n
%    A(:,j) = A(:,j)/norm(A(:,j));
%end
%��˹������
sr=sigma*randn(m,1);
%��������
%sr=sigma*raylrnd(1,m,1);
%����٤������
%sr=sigma*gamrnd(1,2,[m,1]);
%����ָ������
%sr=sigma*exprnd(2,[m,1]);
%���Ӿ��ȷֲ�����
%sr=sigma*unifrnd(0,2,[m,1]);
b = A*x + sr;
%norm(sr)^2


% algorithm parameter
Lf=2*max([norm(deta*abs(A)'*abs(A)*ones(n,1)-A'*b,inf),norm(deta*(-abs(A)'*abs(A)*ones(n,1)-A'*b),inf)]);
%Lf1=norm(A,inf);
%Lf2=norm(A);
%Lf=2*norm(A)*norm(sr);
v=0.99*min(lambda/Lf,deta);
Ls=2*eigs(A*A',1);
%Ls=norm(A)^2;
c=Ls/4;
alphaB1=Ls/8;
alphaB2=Ls/15;
rho=2;
%alphab1=1e-8;
%alphab2=1e+8;
%alpha00=1;
%re_freq = 200;
% run
x0=-ones(n,1);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1(1,k)=toc;
Iter_ag1(1,k)=iter;
MSE_ag1(1,k)=norm(x_new-x)^2/n;
dX_ag1(1,k)=norm(x_new-x_old);
dF_ag1(1,k)=abs(F-F1);
Z_ag1(1,k)=sum(abs(x_new) > 0);
a_ag1(1,k)=a;
S_ag1(1,:)=[mean(Iter_ag1(1,:));mean(Time_ag1(1,:));mean(MSE_ag1(1,:));mean(dX_ag1(1,:));mean(dF_ag1(1,:));mean(Z_ag1(1,:));mean(a_ag1(1,:))];

tic
[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1_R(1,k)=toc;
Iter_ag1_R(1,k)=iter;
MSE_ag1_R(1,k)=norm(x_new-x)^2/n;
dX_ag1_R(1,k)=norm(x_new-x_old);
dF_ag1_R(1,k)=abs(F-F1);
Z_ag1_R(1,k)=sum(abs(x_new) > 0);
a_ag1_R(1,k)=a;
S_ag1_R(1,:)=[mean(Iter_ag1_R(1,:));mean(Time_ag1_R(1,:));mean(MSE_ag1_R(1,:));mean(dX_ag1_R(1,:));mean(dF_ag1_R(1,:));mean(Z_ag1_R(1,:));mean(a_ag1_R(1,:))];

x0=zeros(n,1);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1(2,k)=toc;
Iter_ag1(2,k)=iter;
MSE_ag1(2,k)=norm(x_new-x)^2/n;
dX_ag1(2,k)=norm(x_new-x_old);
dF_ag1(2,k)=abs(F-F1);
Z_ag1(2,k)=sum(abs(x_new) > 0);
a_ag1(2,k)=a;
S_ag1(2,:)=[mean(Iter_ag1(2,:));mean(Time_ag1(2,:));mean(MSE_ag1(2,:));mean(dX_ag1(2,:));mean(dF_ag1(2,:));mean(Z_ag1(2,:));mean(a_ag1(2,:))];

tic
[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1_R(2,k)=toc;
Iter_ag1_R(2,k)=iter;
MSE_ag1_R(2,k)=norm(x_new-x)^2/n;
dX_ag1_R(2,k)=norm(x_new-x_old);
dF_ag1_R(2,k)=abs(F-F1);
Z_ag1_R(2,k)=sum(abs(x_new) > 0);
a_ag1_R(2,k)=a;
S_ag1_R(2,:)=[mean(Iter_ag1_R(2,:));mean(Time_ag1_R(2,:));mean(MSE_ag1_R(2,:));mean(dX_ag1_R(2,:));mean(dF_ag1_R(2,:));mean(Z_ag1_R(2,:));mean(a_ag1_R(2,:))];

x0=ones(n,1);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1(3,k)=toc;
Iter_ag1(3,k)=iter;
MSE_ag1(3,k)=norm(x_new-x)^2/n;
dX_ag1(3,k)=norm(x_new-x_old);
dF_ag1(3,k)=abs(F-F1);
Z_ag1(3,k)=sum(abs(x_new) > 0);
a_ag1(3,k)=a;
S_ag1(3,:)=[mean(Iter_ag1(3,:));mean(Time_ag1(3,:));mean(MSE_ag1(3,:));mean(dX_ag1(3,:));mean(dF_ag1(3,:));mean(Z_ag1(3,:));mean(a_ag1(3,:))];

tic
[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1_R(3,k)=toc;
Iter_ag1_R(3,k)=iter;
MSE_ag1_R(3,k)=norm(x_new-x)^2/n;
dX_ag1_R(3,k)=norm(x_new-x_old);
dF_ag1_R(3,k)=abs(F-F1);
Z_ag1_R(3,k)=sum(abs(x_new) > 0);
a_ag1_R(3,k)=a;
S_ag1_R(3,:)=[mean(Iter_ag1_R(3,:));mean(Time_ag1_R(3,:));mean(MSE_ag1_R(3,:));mean(dX_ag1_R(3,:));mean(dF_ag1_R(3,:));mean(Z_ag1_R(3,:));mean(a_ag1_R(3,:))];

x0=2*ones(n,1);
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1(4,k)=toc;
Iter_ag1(4,k)=iter;
MSE_ag1(4,k)=norm(x_new-x)^2/n;
dX_ag1(4,k)=norm(x_new-x_old);
dF_ag1(4,k)=abs(F-F1);
Z_ag1(4,k)=sum(abs(x_new) > 0);
a_ag1(4,k)=a;
S_ag1(4,:)=[mean(Iter_ag1(4,:));mean(Time_ag1(4,:));mean(MSE_ag1(4,:));mean(dX_ag1(4,:));mean(dF_ag1(4,:));mean(Z_ag1(4,:));mean(a_ag1(4,:))];

tic
[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1_R(4,k)=toc;
Iter_ag1_R(4,k)=iter;
MSE_ag1_R(4,k)=norm(x_new-x)^2/n;
dX_ag1_R(4,k)=norm(x_new-x_old);
dF_ag1_R(4,k)=abs(F-F1);
Z_ag1_R(4,k)=sum(abs(x_new) > 0);
a_ag1_R(4,k)=a;
S_ag1_R(4,:)=[mean(Iter_ag1_R(4,:));mean(Time_ag1_R(4,:));mean(MSE_ag1_R(4,:));mean(dX_ag1_R(4,:));mean(dF_ag1_R(4,:));mean(Z_ag1_R(4,:));mean(a_ag1_R(4,:))];

x0=3*rand(n,1)-1;
tic
[F,F1,x_new,x_old,iter,a] = alg1( n, A, b, lambda, alphaB1, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1(5,k)=toc;
Iter_ag1(5,k)=iter;
MSE_ag1(5,k)=norm(x_new-x)^2/n;
dX_ag1(5,k)=norm(x_new-x_old);
dF_ag1(5,k)=abs(F-F1);
Z_ag1(5,k)=sum(abs(x_new) > 0);
a_ag1(5,k)=a;
S_ag1(5,:)=[mean(Iter_ag1(5,:));mean(Time_ag1(5,:));mean(MSE_ag1(5,:));mean(dX_ag1(5,:));mean(dF_ag1(5,:));mean(Z_ag1(5,:));mean(a_ag1(5,:))];

tic
[F,F1,x_new,x_old,iter,a] = alg1_R( n, A, b, lambda, alphaB2, deta, v, c, rho, maxiter1, tol, x0);
Time_ag1_R(5,k)=toc;
Iter_ag1_R(5,k)=iter;
MSE_ag1_R(5,k)=norm(x_new-x)^2/n;
dX_ag1_R(5,k)=norm(x_new-x_old);
dF_ag1_R(5,k)=abs(F-F1);
Z_ag1_R(5,k)=sum(abs(x_new) > 0);
a_ag1_R(5,k)=a;
S_ag1_R(5,:)=[mean(Iter_ag1_R(5,:));mean(Time_ag1_R(5,:));mean(MSE_ag1_R(5,:));mean(dX_ag1_R(5,:));mean(dF_ag1_R(5,:));mean(Z_ag1_R(5,:));mean(a_ag1_R(5,:))];

end
save S_ag1_3in1600.mat S_ag1
save S_ag1_R_3in1600.mat S_ag1_R